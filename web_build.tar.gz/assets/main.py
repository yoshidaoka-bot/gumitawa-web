import pygame
import random
import sys
import math
import webbrowser
import urllib.parse
import os
import subprocess
import json
import hashlib
import hmac

def copy_image_to_clipboard(filepath):
    if os.name == 'nt':
        try:
            abs_path = os.path.abspath(filepath).replace("'", "''")
            cmd = f'powershell -command "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; [System.Windows.Forms.Clipboard]::SetImage([System.Drawing.Image]::FromFile(\'{abs_path}\'))"'
            subprocess.run(cmd, shell=True, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000))
        except Exception as e:
            print("Clipboard copy failed:", e)
            
def resource_path(relative_path):
    """ PyInstallerなどの実行環境でもファイルを正しく参照するためのパス解決関数 """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# --- 初期設定 ---
WIDTH, HEIGHT = 800, 600
GRID_SIZE = 9
CELL_SIZE = 40
FPS = 30

# --- クオータービュー設定 ---
ISO_TILE_WIDTH = 64
ISO_TILE_HEIGHT = 32
# フィールドの中心座標
ISO_OFFSET_X = 280 
ISO_OFFSET_Y = 120

def to_iso(gx, gy, z=0):
    """グリッド座標 (0-8) をクオータービューのスクリーン座標に変換する"""
    # 直感的な操作感のための不等角投影 (UP=ほぼ上, RIGHT=ほぼ右)
    # 角度を浅くし、軸の傾きを調整
    rx = ISO_OFFSET_X + gx * 45 - gy * 24
    ry = ISO_OFFSET_Y + gx * 12 + gy * 30 - z
    return (rx, ry)

# グリッドの描画オフセット（後方互換性のため残すが、QVではISO_OFFSETを使用）
GRID_OFFSET_X = 220
GRID_OFFSET_Y = 120

# カラーパレット（ファンシーなグミカラーを意識）
WHITE = (255, 255, 255)
BG_COLOR = (255, 230, 245) # 全体の背景色 (濃いめのパステルピンク)
BLACK = (90, 70, 90) # テキスト等に使う暗いパープルグレー
WALL_COLOR = (210, 150, 230) # リッチなパステルパープル系の壁
PLAYER_COLOR = (80, 200, 255) # ぷるぷるの青グミ
EXIT_COLOR = (140, 220, 140) # くすんだ緑グミ（脱出地点）
PANEL_BG = (245, 215, 235) # サイドパネルの背景 (深めのパステルパープルピンク)
GRID_COLOR = (255, 245, 255) # タイルの基本色（白っぽくて柔らかい）
FIELD_COLOR = (235, 195, 230) # タイルの下地となる床の色（濃いめのピンク紫）

# 個別エネミーカラー
ENEMY_COLORS = {
    "E1": (255, 100, 100), # 赤グミ (犬型)
    "E2": (255, 165, 0),   # オレンジ (猫型)
    "E3": (255, 192, 203), # ピンク (ウサギ型)
    "E4": (160, 120, 80),  # 茶色 (ウシ型)
    "BOSS": (200, 100, 255) # ボス (紫)
}

# 音の遅延を防ぐための初期設定
try:
    pygame.mixer.pre_init(44100, -16, 1, 512)
except:
    pass
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("GUMITAWA")

def generate_8bit_sound(freqs, duration, volume=0.1):
    """
    指定された周波数のリストから簡易的な8bit風の矩形波サウンドを生成する。
    freqs: [(start_freq, end_freq), ...] または単一の周波数
    """
    import array
    sample_rate = 44100
    samples = []
    
    # 複数音の合成（アルペジオなど）
    if not isinstance(freqs, list): freqs = [freqs]
    
    # 1音あたりの時間
    single_dur = duration / len(freqs)
    
    for f in freqs:
        f_start, f_end = (f, f) if isinstance(f, (int, float)) else f
        n_samples = int(sample_rate * single_dur)
        for i in range(n_samples):
            # 周波数のスイープ（音程の変化）
            curr_f = f_start + (f_end - f_start) * (i / n_samples)
            if curr_f == 0:
                samples.append(0)
                continue
            period = sample_rate / curr_f
            val = int(volume * 16384) if (i % period) < (period / 2) else int(-volume * 16384)
            samples.append(val)
            
    # Pygameで使用可能なSoundオブジェクトに変換
    sound_array = array.array('h', samples)
    return pygame.mixer.Sound(buffer=sound_array)

# --- BGM生成用データ ---
# 音名と周波数の対応（C3〜B5）
NOTE_FREQS = {
    'C3': 130.81, 'C#3': 138.59, 'D3': 146.83, 'D#3': 155.56, 'E3': 164.81, 'F3': 174.61,
    'F#3': 185.00, 'G3': 196.00, 'G#3': 207.65, 'A3': 220.00, 'A#3': 233.08, 'B3': 246.94,
    'C4': 261.63, 'C#4': 277.18, 'D4': 293.66, 'D#4': 311.13, 'E4': 329.63, 'F4': 349.23,
    'F#4': 369.99, 'G4': 392.00, 'G#4': 415.30, 'A4': 440.00, 'A#4': 466.16, 'B4': 493.88,
    'C5': 523.25, 'C#5': 554.37, 'D5': 587.33, 'D#5': 622.25, 'E5': 659.25, 'F5': 698.46,
    'F#5': 739.99, 'G5': 783.99, 'G#5': 830.61, 'A5': 880.00, 'A#5': 932.33, 'B5': 987.77,
    'R': 0 # 休符
}

def generate_8bit_track(melody_seq, bpm, volume=0.04):
    """
    音名と長さ(拍数)のリストからBGMトラックを生成。
    melody_seqがリストのリストであれば、複数トラックとしてミックスする。
    """
    import array
    if not melody_seq: return None
    
    # 単一トラックか複数トラックかを判定
    if isinstance(melody_seq[0], list):
        tracks = melody_seq
    else:
        tracks = [melody_seq]
        
    sample_rate = 44100
    beat_dur = 60.0 / bpm
    
    # 全体の最大サンプル数を計算
    max_beats = 0
    for t in tracks:
        total_b = sum(beats for _, beats in t)
        if total_b > max_beats: max_beats = total_b
    
    total_samples = int(sample_rate * max_beats * beat_dur)
    samples = [0] * total_samples
    
    for t in tracks:
        curr_sample = 0
        for note, beats in t:
            freq = NOTE_FREQS.get(note, 0)
            dur = beats * beat_dur
            n_samples = int(sample_rate * dur)
            
            if freq > 0:
                period = sample_rate / freq
                for i in range(n_samples):
                    if curr_sample + i >= total_samples: break
                    # 矩形波：デューティ比30%
                    val = int(volume * 16384) if (i % period) < (period * 0.3) else int(-volume * 16384)
                    # フェードアウトしてプツプツ音を抑える
                    if i > n_samples - 200:
                        val = int(val * (n_samples - i) / 200)
                    samples[curr_sample + i] += val
            curr_sample += n_samples
            
    # 合成されたサンプルを16bit整数配列に変換
    # 複数トラック合成によるクリッピング防止のため、最大値でクリップ
    final_samples = []
    for s in samples:
        if s > 32767: s = 32767
        if s < -32768: s = -32768
        final_samples.append(s)
            
    sound_array = array.array('h', final_samples)
    return pygame.mixer.Sound(buffer=sound_array)

ALL_SKILLS = {
    "回復": {"j": 1, "g": 1, "desc": "体力を3回復", "once": False},
    "貫通": {"j": 0, "g": 1, "desc": "壁を壊して進める", "once": False},
    "回転": {"j": 2, "g": 0, "desc": "周囲8マスの敵を攻撃", "once": False},
    "投擲": {"j": 1, "g": 1, "desc": "直線上の敵を攻撃", "once": False},
    "停止": {"j": 0, "g": 2, "desc": "5ターン敵が停止（ボス無効）", "once": True},
    "跳躍": {"j": 1, "g": 0, "desc": "1マス飛ばして移動", "once": False},
    "重撃": {"j": 2, "g": 5, "desc": "9ダメ(ボス有効)", "once": True},
    "自爆": {"j": -1, "g": -1, "desc": "敵全滅/HP1/J・G全消費", "once": True}
}

# 言語設定
TRANSLATIONS = {
    "JP": {
        "title_endless": "エンドレス", "title_time_attack": "タイムアタック", "title_time_limit": "タイムリミット",
        "label_how_to": "遊びかた", "label_skills": "スキル解説", "label_chars": "キャラクター", "label_story": "ストーリー",
        "label_lang": "Language: JP",
        "ui_floor": "たかさ", "ui_turns": "この階あと", "ui_turns_unit": "ターン", "ui_time_left": "この階あと", "ui_time_limit": "のこり時間",
        "ui_elapsed": "経過時間", "ui_hp": "HP", "ui_item_j": "J (ジュース)", "ui_item_g": "G (ゼラチン)",
        "ui_boss_name": "おっきなグミ",
        "skill_heal": "体力を3回復", "skill_pierce": "壁を壊して進める", "skill_spin": "周囲8マスの敵を攻撃",
        "skill_throw": "直線上の敵を攻撃", "skill_stop": "5ターン敵が停止（ボス無効）", "skill_jump": "1マス飛ばして移動",
        "skill_heavy": "9ダメ(ボス有効)", "skill_bomb": "敵全滅/HP1/J・G全消費",
        "msg_press_z": "Zキーを押してください", "msg_retry": "リトライ", "msg_back_lobby": "ロビーへもどる", "msg_save": "結果を保存",
        "story_title": "【 あらすじ 】",
        "story_1": "あなたはグミです。",
        "story_2": "空から降って来る大量のグミをよけつづけ、",
        "story_3": "より高い場所を目指しましょう。",
        "ui_surface": "【地表】",
        "how_to_title": "【 遊びかた 】",
        "how_to_1": "・[矢印キー] : 移動",
        "how_to_2": "・[Z] + [方向] : スキルを使用",
        "how_to_3": "・[Z] 2回押し : 1回休み（動かない）",
        "skill_title": "【 スキル解説 】",
        "char_title": "【 キャラクター 】",
        "char_me": "あなたです。グミの塔を登っている。",
        "char_e1": "赤い。追いかけてくる。",
        "char_e2": "オレンジ。気まぐれに動く。",
        "char_e3": "ピンク。壁を飛び越える。",
        "char_e4": "茶色。体当たりで1マス飛ばす。",
        "char_boss": "大きなグミ。ダメージで小さくなる。",
        "menu_ta_target": "タイムアタック 目標のたかさ",
        "menu_tl_limit": "タイムリミット 制限時間",
        "menu_controls": "[↑↓] 選択  [Z] 決定  [→] もどる",
        "res_clear": "ゲームクリア！",
        "res_time_up": "タイムアップ！",
        "res_total_turns": "総ターン数",
        "res_clear_time": "クリアタイム",
        "res_retry": "もういちど",
        "res_share": "結果を共有",
    },
    "EN": {
        "title_endless": "Endless", "title_time_attack": "Time Attack", "title_time_limit": "Time Limit",
        "label_how_to": "How to Play", "label_skills": "Skills", "label_chars": "Characters", "label_story": "Story",
        "label_lang": "Language: EN",
        "ui_floor": "Floor", "ui_turns": "Turns left", "ui_turns_unit": "turns", "ui_time_left": "Time left", "ui_time_limit": "Remaining",
        "ui_elapsed": "Total Time", "ui_hp": "HP", "ui_item_j": "J (Juice)", "ui_item_g": "G (Gelatin)",
        "ui_boss_name": "Huge Gummy",
        "skill_heal": "Heal 3 HP", "skill_pierce": "Break walls to move", "skill_spin": "Attack 8 neighbors",
        "skill_throw": "Attack in a line", "skill_stop": "Stop enemies for 5 turns (Bosses immune)", "skill_jump": "Jump over 1 cell",
        "skill_heavy": "9 Damage (Boss OK)", "skill_bomb": "Wipe enemies/HP1/Lose J+G",
        "msg_press_z": "Press Z Key", "msg_retry": "Retry", "msg_back_lobby": "Back to Lobby", "msg_save": "Save Result",
        "story_title": "[ Synopsis ]",
        "story_1": "You are a gummy.",
        "story_2": "Avoid the falling gummies,",
        "story_3": "and aim for the top of the tower.",
        "ui_surface": "Surface",
        "how_to_title": "[ How to Play ]",
        "how_to_1": "- [Arrow Keys]: Move",
        "how_to_2": "- [Z] + [Dir]: Use Skill",
        "how_to_3": "- [Z] Twice: Wait 1 Turn",
        "skill_title": "[ Skills ]",
        "char_title": "[ Characters ]",
        "char_me": "It's you. Climbing the tower.",
        "char_e1": "Red. Chases you.",
        "char_e2": "Orange. Moves randomly.",
        "char_e3": "Pink. Jumps over walls.",
        "char_e4": "Brown. Pushes you back.",
        "char_boss": "Huge Gummy. Shrinks when hit.",
        "menu_ta_target": "Time Attack: Target Height",
        "menu_tl_limit": "Time Limit: Duration",
        "menu_controls": "[↑↓] Change  [Z] Start  [→] Back",
        "res_clear": "GAME CLEAR!",
        "res_time_up": "TIME UP!",
        "res_total_turns": "Total Turns",
        "res_clear_time": "Clear Time",
        "res_retry": "Retry",
        "res_share": "Share Result",
    }
}

class SaveManager:
    SECRET_KEY = b"GUMITAWA_SECRET_2026"
    SAVE_PATH = "save_v1.dat"

    @classmethod
    def save(cls, data):
        try:
            json_data = json.dumps(data)
            signature = hmac.new(cls.SECRET_KEY, json_data.encode(), hashlib.sha256).hexdigest()
            full_data = {"payload": data, "signature": signature}
            with open(cls.SAVE_PATH, "w") as f:
                json.dump(full_data, f)
        except Exception as e:
            print(f"Save error: {e}")

    @classmethod
    def load(cls):
        if not os.path.exists(cls.SAVE_PATH):
            return {"achievements": [], "max_floor": 0, "lang": "JP"}
        try:
            with open(cls.SAVE_PATH, "r") as f:
                full_data = json.load(f)
            data = full_data["payload"]
            sig = full_data["signature"]
            expected_sig = hmac.new(cls.SECRET_KEY, json.dumps(data).encode(), hashlib.sha256).hexdigest()
            if hmac.compare_digest(sig, expected_sig):
                if "lang" not in data: data["lang"] = "JP"
                return data
            else:
                print("Save data tampered!")
                return {"achievements": [], "max_floor": 0, "lang": "JP"}
        except Exception as e:
            print(f"Load error: {e}")
            return {"achievements": [], "max_floor": 0, "lang": "JP"}

# フォントの初期設定
def get_font(size, bold=False):
    # 同梱したフォントファイルを優先
    path = resource_path("font.ttf")
    if os.path.exists(path):
        try:
            return pygame.font.Font(path, size)
        except:
            pass
    # ファイルがない、または読み込めない場合はシステムフォントで代用
    # Windowsなら Meiryo, なければ sans-serif
    return pygame.font.SysFont(["meiryo", "msgothic", "notosansjp", "sans-serif"], size, bold=bold)

try:
    font = get_font(20)
    bold_font = get_font(20, bold=True)
    title_font = get_font(28, bold=True)
    small_font = get_font(14)
    huge_font = get_font(120, bold=True)
except:
    font = pygame.font.Font(None, 24)
    bold_font = pygame.font.Font(None, 24)
    title_font = pygame.font.Font(None, 36)
    small_font = pygame.font.Font(None, 18)
    huge_font = pygame.font.Font(None, 120)


# 頂点計算テーブルの事前作成 (Idea 4: 毎フレームの sin/cos 計算を避ける)
ISO_VERTEX_TABLE = []
for i in range(4):
    radius = 0.4
    centers = [(radius, radius), (1-radius, radius), (1-radius, 1-radius), (radius, 1-radius)]
    angles = [(math.pi, 1.5*math.pi), (1.5*math.pi, 2*math.pi), (0, 0.5*math.pi), (0.5*math.pi, math.pi)]
    c_x, c_y = centers[i]
    a_start, a_end = angles[i]
    for step in range(4):
        angle = a_start + (a_end - a_start) * (step / 3)
        # to_iso の線形性を利用し、相対座標 (dx, dy) を計算
        dx = c_x + math.cos(angle) * radius
        dy = c_y + math.sin(angle) * radius
        ISO_VERTEX_TABLE.append((dx, dy))

class GameState:
    def __init__(self):
        self.floor = 1
        self.hp = 10
        self.j = 3
        self.g = 3
        self.lang = "JP"
        self.turns_left = 30
        self.time_left = 30.0
        self.total_time = 0.0
        self.total_turns_taken = 0
        self.gameover_anim_timer = 0.0
        self.needs_reset = None
        self.waiting_for_enemy_turn = False
        self.death_cause = "FALL" # FALL or DEAD
        self.dropped_enemies = 0
        self.DROPPED_TO_BOSS = 9 # 初期値9
        
        self.save_data = SaveManager.load()
        self.itemless_unlocked = "ITEMLESS_ENDLESS" in self.save_data.get("achievements", [])
        
        self.flavor_tiles = {}
        self.caramel_stuck = False
        self.popping_active = False
        self.pool_enemies = [] # [{"x":..., "y":..., "vx":..., "vy":..., "type":..., "phase":...}]
        self.boss_intro_state = None # "MERGING", "LEAPING", "FALLING", "BLASTING"
        self.boss_intro_timer = 0.0
        
        # スキルシステム
        self.skills = {"UP": "回復", "RIGHT": "貫通", "DOWN": "", "LEFT": ""}
        self.pierce_buff = False
        self.jump_buff = False
        self.stop_buff = 0 # 0より大きい間、敵が動かない
        self.stop_beep_timer = 0.0 # 停止中のビープ音用タイマー
        self.boss_spawn_timer = 0 # 10ターンごとにエネミーを出す用
        self.items = []
        self.flying_enemies = []
        
        # プレイヤーの攻撃アニメーション用
        self.attack_anim_dx = 0
        self.attack_anim_dy = 0
        self.attack_anim_timer = 0.0
        
        self.pushback_anim_dx = 0
        self.pushback_anim_dy = 0
        self.pushback_anim_timer = 0.0
        
        self.move_anim_dx = 0
        self.move_anim_dy = 0
        self.move_anim_timer = 0.0
        self.move_anim_max_timer = 0.075
        self.is_sliding = False
        
        self.spin_anim_timer = 0.0
        self.throw_anim_timer = 0.0
        self.throw_anim_dx = 0
        self.throw_anim_dy = 0
        self.wait_anim_timer = 0.0
        self.player_facing_dx = 1
        self.player_facing_dy = 0
        
        self.countdown_timer = 0.0
        self.state = "TITLE" # 状態: TITLE, LOBBY, COUNTDOWN, PLAYING, SHOP, GAMEOVER, LOBBY_MENU, GAMECLEAR, LOBBY_LIMIT_MENU
        self.mode = "ENDLESS" # モード: ENDLESS, TIME_ATTACK, TIME_LIMIT
        self.target_floor = 10
        self.target_time = 60.0
        self.cleartime = 0.0
        self.time_attack_start_pos = (7, 4)
        self.time_limit_start_pos = (1, 4)
        self.gameclear_selection = 0
        
        # ショップ用
        self.shop_offers = [] # [{"name":..., "type": "SKILL"/"ITEM", "cost_j":..., "cost_g":...}]
        self.shop_timer = 0.0
        self.shop_item_pos = [(2, 3), (4, 3), (6, 3)]
        self.shop_exit_pos = (4, 0) # 上から1列目、中央 (5,1)
        self.shopkeeper_pos = (4, 6)
        
        self.enemies = []
        self.walls = set()
        self.items = []
        self.exit_pos = None
        self.lobby_start_pos = (4, 4)
        self.player_x = 4
        self.player_y = 4
        self.turns_left = 30
        self.gameover_selection = 0 # 初期化
        
        # ワイプ演出用
        self.wipe_active = False
        self.wipe_timer = 0.0
        self.wipe_bars = []
        self.wipe_callback = None

        # サウンドエフェクトの生成
        try:
            self.se_blow = generate_8bit_sound([(300, 180)], 0.08, 0.25)          # パシィッ！（よりクリアな音）
            self.se_damage = generate_8bit_sound(150, 0.15, 0.1)        # ドスッ
            self.se_next = generate_8bit_sound([1046, 1318, 1568, 2093, 2637, 3136, (3136, 4000), (4000, 1500)], 0.45, 0.05) # シャーン！(きらびやかな上昇＆スイープ)
            self.se_fall = generate_8bit_sound([(1200, 200)], 0.5, 0.05) # ひゅ〜
            self.se_fail = generate_8bit_sound([150, 120], 0.3, 0.1)     # ペブー
            self.se_error = generate_8bit_sound(120, 0.1, 0.1)          # ブッ（エラー）
            self.se_heal = generate_8bit_sound([880, 1174, 1396, 1760, 2093], 0.2, 0.05) # 輝くようなアルペジオ！
            self.se_pickup = generate_8bit_sound([(800, 1200)], 0.05, 0.1)     # ぴゃっ！
            self.se_move = generate_8bit_sound([200, 150], 0.03, 0.05)         # ぷにっ
            self.se_jump = generate_8bit_sound([(300, 1200)], 1.2, 0.15)      # ぴょ～～～～ん（フロア移動・ボス出現用）
            self.se_jump_move = generate_8bit_sound([(200, 800)], 0.3, 0.15)  # ぴょん！（跳躍移動用）
            self.se_start = generate_8bit_sound([261, 329, 392, 523, 659, 783, 1046], 0.4, 0.04) # ビロリロリーーン！
            
            # --- スキル用SE ---
            self.se_pierce_charge = generate_8bit_sound([(600, 1500)], 0.2, 0.1) # フィイン（貫通溜め）
            self.se_pierce_break = generate_8bit_sound([(250, 100), (200, 80)], 0.15, 0.3) # ドドゥン（貫通破壊）
            self.se_spin = generate_8bit_sound([(400, 800), (800, 400)], 0.2, 0.1)  # シュワワン（回転）
            self.se_throw = generate_8bit_sound([(400, 1000)], 0.05, 0.1)           # ピュッ（投擲）
            self.se_stop = generate_8bit_sound([440, 0, 330, 0], 0.2, 0.1)          # チッカッ（停止発動時）
            self.se_stop_beep = generate_8bit_sound([1000], 0.05, 0.05)            # ピッ（停止中のビープ音）
            self.se_poyo = generate_8bit_sound([(300, 600)], 0.15, 0.1)             # ポヨォン（跳躍）
            self.se_heavy = generate_8bit_sound([(120, 40), (100, 30)], 0.2, 0.25)  # ボグシャッ（重撃・音量注意）
            self.se_bomb = generate_8bit_sound([(100, 20), (50, 10)], 0.5, 0.4)     # ドゴォォン（自爆）
            self.se_land = generate_8bit_sound([(100, 50)], 0.2, 0.2)               # ズシン（着地）
            self.se_puff = generate_8bit_sound([(300, 150)], 0.05, 0.05)             # パフッ（砂埃）
            
            # --- BGM生成 (作曲) ---
            # Main Theme (BPM 110) - 16小節ループ化
            m1 = [('C4',0.5),('E4',0.5),('G4',0.5),('C5',0.5),('B4',0.5),('A4',0.5),('G4',1.0), # 1: C Major Arpeggio
                  ('F4',0.5),('A4',0.5),('C5',0.5),('A4',0.5),('G4',0.5),('E4',0.5),('C4',1.0), # 2: F -> C
                  ('A4',0.5),('C5',0.5),('D5',1.0),('C5',0.5),('A4',0.5),('G4',1.0),           # 3: Lift up
                  ('F4',0.5),('G4',0.5),('A4',0.5),('B4',0.5),('C5',2.0)]                      # 4: Finale
            
            m2 = [('E5',0.5),('D5',0.5),('C5',0.5),('B4',0.5),('C5',1.0),('G4',1.0),           # 5: B-section
                  ('A4',0.5),('B4',0.5),('C5',0.5),('D5',0.5),('E5',1.0),('C5',1.0),           # 6
                  ('F5',0.5),('E5',0.5),('D5',0.5),('C5',0.5),('B4',1.0),('G4',1.0),           # 7
                  ('A4',0.5),('G4',0.5),('F4',0.5),('G4',0.5),('C5',2.0)]                      # 8
            
            m3 = [('G5',0.5),('F5',0.5),('E5',0.5),('C5',0.5),('D5',1.0),('G4',1.0),           # 9: Climax
                  ('A4',0.5),('B4',0.5),('C5',0.5),('D5',0.5),('E5',0.5),('G5',0.5),('C6',1.0), # 10
                  ('B5',0.5),('A5',0.5),('G5',1.0),('F5',0.5),('D5',0.5),('C5',1.0),           # 11
                  ('F4',0.5),('G4',0.5),('A4',0.5),('B4',0.5),('C5',2.0)]                      # 12
            
            main_m = m1 + m2 + m1 + m3 # 4+4+4+4 = 16 bars
            
            # Bass line (16 bars)
            b1 = [('C3', 1.0), ('G3', 1.0), ('C3', 1.0), ('G3', 1.0),
                  ('F3', 1.0), ('C3', 1.0), ('F3', 1.0), ('C3', 1.0),
                  ('A3', 1.0), ('E3', 1.0), ('D3', 1.0), ('G3', 1.0),
                  ('F3', 1.0), ('G3', 1.0), ('C3', 2.0)]
            
            b2 = [('E3', 1.0), ('A3', 1.0), ('E3', 1.0), ('A3', 1.0),
                  ('D3', 1.0), ('G3', 1.0), ('D3', 1.0), ('G3', 1.0),
                  ('C3', 1.0), ('F3', 1.0), ('D3', 1.0), ('G3', 1.0),
                  ('C3', 1.0), ('G3', 1.0), ('C3', 2.0)]
            
            b3 = [('G3', 1.0), ('F3', 1.0), ('E3', 1.0), ('C3', 1.0),
                  ('F3', 1.0), ('G3', 1.0), ('A3', 1.0), ('B3', 1.0),
                  ('C4', 1.0), ('G3', 1.0), ('A3', 1.0), ('B3', 1.0),
                  ('C4', 1.0), ('G3', 1.0), ('C3', 2.0)]
            
            main_b = b1 + b2 + b1 + b3
            
            self.bgm_main = generate_8bit_track([main_m, main_b], 110, 0.03)
            
            # Boss Battle (BPM 180)
            boss_m = [('A3',0.25),('C4',0.25),('E4',0.25),('A4',0.25),('G#4',0.25),('E4',0.25),('C4',0.25),('G#3',0.25)]
            self.bgm_boss = generate_8bit_track(boss_m * 8, 180, 0.04)
            
            # Shop Music (Jazz/AOR風 BPM 85)
            shop_m = [('F4',1.0),('E4',0.5),('D4',0.5),('E4',1.0),('C4',1.0),
                      ('F4',0.5),('G4',0.5),('A4',1.0),('G4',2.0),
                      ('D4',1.0),('F4',0.5),('G4',0.5),('E4',2.0)]
            self.bgm_shop = generate_8bit_track(shop_m, 85, 0.03)
            
            # Lobby Music (Calm/Peaceful BPM 90)
            lobby_m = [('E4',1.0),('G4',1.0),('B4',1.0),('G4',1.0),
                       ('F4',1.0),('A4',1.0),('C5',1.0),('A4',1.0),
                       ('D4',1.0),('F4',1.0),('A4',1.0),('F4',1.0),
                       ('E4',1.0),('G4',1.0),('B4',1.0),('G4',1.0)]
            self.bgm_lobby = generate_8bit_track(lobby_m, 90, 0.03)
            
            self.current_bgm = None
        except:
            self.se_pierce_charge = self.se_pierce_break = self.se_spin = self.se_throw = self.se_stop = self.se_poyo = self.se_heavy = self.se_bomb = self.se_land = self.se_puff = None
            self.bgm_main = self.bgm_boss = self.bgm_shop = self.bgm_lobby = None
            self.current_bgm = None
        self.time_left = 30.0
        self.fail_sound_timer = 0.0 # ゲームオーバー時の間隔用
        
        # ボス戦用
        self.boss_active = False
        self.boss_hp = 0
        self.boss_max_hp = 9
        self.boss_x = 0
        self.boss_y = 0
        self.boss_facing_dx = 1
        self.boss_facing_dy = 0
        self.boss_move_timer = 0 # 2ターンに1回移動用
        self.boss_damage_timer = 0.0 # ボスの被ダメージ演出用

        self.screen_shake = 0.0 # 画面揺れ演出用
        
        self.current_bgm = None
        
        # 階層移動トランジション用
        self.transition_timer = 0.0
        self.transition_direction = 0 # 1: 拡大(上昇), -1: 縮小(登場), 0: なし
        self.landing_jiggle_timer = 0.0 # 着地時のバウンス演出用
        self.transition_callback = None
        self.damage_face_timer = 0.0 # ダメージ時の表情管理用
        
        self.particles = [] # 煙などのエフェクト用
        self.boss_transform_timer = 0.0 # 0.4秒程度の溜め演出
        self.dying_timer = 0.0 # 落下消滅演出用
        self.death_x = 0
        self.death_y = 0
        self.heal_particles = [] # 回復時のキラキラエフェクト用
        self.heal_texts = [] # 回復量表示テキスト用 (+3など)
        self.visual_push_timer = 0.0 # 敵に攻撃された時の視覚的な押し込まれ演出
        self.visual_push_dx = 0
        self.visual_push_dy = 0
        self.bomb_flash_timer = 0.0 # 自爆のホワイトアウト演出用
        self.heavy_atk_timer = 0.0 # 重撃のジャンプ演出用
        self.heavy_atk_data = None

        # --- 全画面の星空データの初期化 ---
        self.stars = []
        for _ in range(250):
            self.stars.append({
                "x": random.uniform(0, WIDTH),
                "y": random.uniform(0, HEIGHT),
                "size": random.uniform(1, 3),
                "speed": random.uniform(2, 5),
                "phase": random.random() * math.pi * 2
            })

        self.wall_jiggles = {} # {(x, y): [timer, dx, dy]}
        self.scroll_timer = 0.0 # 階層移動後のスクロール演出用
        self.tile_jiggles = {} # {(x, y): timer}
        self.purchase_anim_timer = 0.0 # ショップ購入演出用
        self.purchased_item_idx = -1
        
        # ストーリー用イメージの読み込み
        self.story_image = None
        try:
            img_path = resource_path("story_concept.png")
            if os.path.exists(img_path):
                self.story_image = pygame.image.load(img_path)
                # ポップアップサイズに合わせてリサイズ (幅400pxに合わせる)
                orig_w, orig_h = self.story_image.get_size()
                target_w = 400
                target_h = int(orig_h * (target_w / orig_w))
                self.story_image = pygame.transform.smoothscale(self.story_image, (target_w, target_h))
        except Exception as e:
            print(f"Failed to load story image: {e}")

    def get_sky_color(self, floor=None):
        """階層に応じた空の色を計算する"""
        f = floor if floor is not None else self.floor
        # キーフレーム定義: (階層, 色R, 色G, 色B)
        keyframes = [
            (0, 255, 255, 255),   # 0階: ピュアホワイト
            (15, 235, 245, 255),  # 15階: 極めて淡いブルー
            (25, 25, 25, 112),    # 25階: ミッドナイトブルー
            (35, 5, 5, 20)        # 35階以降: スペースネイビー（宇宙）
        ]
        
        if f <= keyframes[0][0]: return keyframes[0][1:]
        if f >= keyframes[-1][0]: return keyframes[-1][1:]
        
        # 線形補間
        for i in range(len(keyframes)-1):
            f1, r1, g1, b1 = keyframes[i]
            f2, r2, g2, b2 = keyframes[i+1]
            if f1 <= f <= f2:
                t = (f - f1) / (f2 - f1)
                r = int(r1 + (r2 - r1) * t)
                g = int(g1 + (g2 - g1) * t)
                b = int(b1 + (b2 - b1) * t)
                return (r, g, b)
        return keyframes[-1][1:]

    def draw_sky_gradient(self, surface, rect):
        """指定された範囲に高度に応じた垂直グラデーションを描画する"""
        top_color = self.get_sky_color(self.floor + 15) # 上の方は少し先の空
        bottom_color = self.get_sky_color(self.floor)
        
        # 極小のサーフェスを作成して smoothscale で引き伸ばしてグラデーションを作る
        grad_surf = pygame.Surface((1, 2))
        grad_surf.set_at((0, 0), top_color)
        grad_surf.set_at((0, 1), bottom_color)
        
        # rect は (x, y, w, h)
        scaled_grad = pygame.transform.smoothscale(grad_surf, (rect[2], rect[3]))
        surface.blit(scaled_grad, (rect[0], rect[1]))

    def load_story_image(self):
        """ストーリー用イメージを読み込む"""
        try:
            img_path = resource_path("story_concept.png")
            if os.path.exists(img_path):
                self.story_image = pygame.image.load(img_path)
                orig_w, orig_h = self.story_image.get_size()
                target_w = 400
                target_h = int(orig_h * (target_w / orig_w))
                self.story_image = pygame.transform.smoothscale(self.story_image, (target_w, target_h))
        except:
            pass
        
    def start_transition(self, callback):
        """フロア切り替えトランジションを開始する"""
        # 現在のフロアの静的な見た目と動的なオブジェクトを保存 (次のフロアが重なる演出用)
        self.old_floor_data = {
            "walls": list(self.walls),
            "flavor": dict(self.flavor_tiles),
            "enemies": [dict(e) for e in self.enemies],
            "items": [dict(i) for i in self.items],
            "exit_pos": self.exit_pos, # 通常階の出口位置
            "is_shop": (self.state == "SHOP"),
            "player_x": self.player_x,
            "player_y": self.player_y,
            "floor": self.floor
        }
        if self.state == "SHOP":
            self.old_floor_data["shop_items"] = list(self.shop_item_pos)
            self.old_floor_data["shop_offers"] = [dict(o) for o in self.shop_offers]
            self.old_floor_data["shop_exit"] = self.shop_exit_pos
            self.old_floor_data["shopkeeper_pos"] = self.shopkeeper_pos
        
        # 準備時間を挟まず即座に次のフロアを生成し、スライド降下を開始する
        if callback:
            callback()
            
        self.transition_timer = 1.0 # 上端から開始
        self.transition_direction = -1 # 登場フェーズ
        if self.se_next: self.se_next.play()

    def play_bgm(self, bgm_obj):
        if not bgm_obj: return
        if self.current_bgm == bgm_obj: return
        if self.current_bgm: self.current_bgm.stop()
        self.current_bgm = bgm_obj
        self.current_bgm.play(-1)

    def stop_bgm(self):
        if self.current_bgm: self.current_bgm.stop()
        self.current_bgm = None

    def get_tower_bg_color(self):
        """現在の階層に応じた塔の背景色を返す (緑 -> 白 -> 紺)"""
        f = self.floor
        if f <= 6:
            # 最初の緑をより薄く (180, 220, 180) -> 白 (235, 245, 250)
            # 6階で白に到達するようにペースを速める
            t = f / 6.0
            r = int(180 + (235 - 180) * t)
            g = int(220 + (245 - 220) * t)
            b = int(180 + (250 - 180) * t)
            return (r, g, b)
        elif f <= 20:
            # 白 (235, 245, 250) -> 紺 (15, 20, 40)
            # 20階で宇宙に到達するように調整
            t = (f - 6) / 14.0
            r = int(235 + (15 - 235) * t)
            g = int(245 + (20 - 245) * t)
            b = int(250 + (40 - 250) * t)
            return (r, g, b)
        else:
            # 宇宙 (20階以上)
            return (15, 20, 40)

    def clear_stage_data(self):
        """フロア上の動的・静的データをすべてリセットする"""
        self.enemies = []
        self.walls = set()
        self.items = []
        self.flavor_tiles = {}
        self.exit_pos = None
        self.wall_jiggles = {}
        self.screen_shake = 0.0

    def enter_lobby(self, play_music=True):
        if play_music:
            self.play_bgm(self.bgm_lobby)
        self.state = "LOBBY"
        self.player_x = 4
        self.player_y = 7
        self.lobby_start_pos = (4, 4)
        self.time_attack_start_pos = (7, 4)
        self.time_limit_start_pos = (1, 4)
        self.lang_tile_pos = (4, 1)
        # self.itemless_start_pos = (4, 2)
        self.save_data = SaveManager.load()
        self.lang = self.save_data.get("lang", "JP")
        # self.itemless_unlocked = "ITEMLESS_ENDLESS" in self.save_data.get("achievements", [])
        self.clear_stage_data()
        self.floor = 0
        self.hp = 10
        self.j = 3
        self.g = 3
        
    def start_countdown(self, with_wipe=True):
        def _on_covered():
            # カバーされた瞬間にレベル生成などは行うが、カウントダウンは開始しない
            self.floor = 1
            self.generate_level(start_pos=(4, 4))
            self.state = "WAITING_FOR_WIPE"
            
        if with_wipe:
            self.start_wipe(_on_covered)
        else:
            _on_covered()

    def start_wipe(self, callback):
        self.wipe_active = True
        self.wipe_timer = 0.0
        self.wipe_callback = callback
        self.wipe_bars = []
        num_bars = 10
        bar_h = HEIGHT // num_bars
        colors = [
            (170, 220, 255), # パステルブルー
            (180, 240, 190), # パステルグリーン
            (230, 180, 255), # パステルパープル
            (255, 190, 200), # パステルピンク
            (255, 220, 160)  # パステルオレンジ
        ]
        for i in range(num_bars):
            self.wipe_bars.append({
                "y": i * bar_h,
                "h": bar_h + 2,
                "delay": i * 0.02,
                "color": colors[i % len(colors)]
            })
        
    def trigger_gameover(self, dx=0, dy=0, cause="FALL"):
        if self.state in ("GAMEOVER", "DYING"): return
        self.stop_bgm()
        
        # ひゅ〜音を再生し、ペブー音は1秒後に予約
        if self.se_fall: self.se_fall.play()
        self.fail_sound_timer = 1.0
        self.death_cause = cause
        
        # どの死因でもまずは縮小演出（DYING）へ
        self.death_x = self.player_x + dx
        self.death_y = self.player_y + dy
        self.state = "DYING"
        self.dying_timer = 0.6
        self.move_anim_timer = 0.0
        
        # 吹き飛ばし演出用初期値（ピクセル単位）
        self.death_px = GRID_OFFSET_X + self.player_x * CELL_SIZE
        self.death_py = GRID_OFFSET_Y + self.player_y * CELL_SIZE
        self.death_vx = 0
        self.death_vy = 0
        
        if cause == "DEAD":
            # 敵と同じ吹き飛びロジックを適用
            if dx == 0 and dy == 0:
                dx, dy = random.choice([(1,0),(-1,0),(0,1),(0,-1)])
            base_angle = math.atan2(dy, dx)
            angle = base_angle + random.uniform(-0.6, 0.6)
            speed = random.uniform(1000, 1500)
            self.death_vx = math.cos(angle) * speed
            self.death_vy = math.sin(angle) * speed
            
            # --- エネミープール（地表パネル）への追加 ---
            # 敵が倒された時と同じように、即座にプールへ（画面外上空から降ってくる演出用）
            self.pool_enemies.append({
                "x": random.uniform(20, 170), 
                "y": -50, 
                "vx": random.uniform(-100, 100),
                "vy": random.uniform(400, 600),
                "type": "PLAYER",
                "phase": random.random() * math.pi * 2,
                "radius": 12
            })


    def enter_shop(self):
        """ショップ画面（休憩所）へ遷移"""
        self.play_bgm(self.bgm_shop)
        self.state = "SHOP"
        self.player_x, self.player_y = 4, 1 # 上から2列目、中央 (5,2)
        self.shop_timer = 30.0
        self.shop_offers = []
        
        # フロア上の残留物を完全にクリア
        self.clear_stage_data()
        
        # 商品生成: スキル2つ確定、1つはスキルかアイテム
        skill_names = list(ALL_SKILLS.keys())
        random.shuffle(skill_names)
        
        # スロット1, 2
        for i in range(2):
            name = skill_names[i]
            s = ALL_SKILLS[name]
            # 購入コストは0にする
            self.shop_offers.append({"name": name, "type": "SKILL", "j": 0, "g": 0, "desc": s["desc"]})
            
        # スロット3 (スキルかアイテム)
        if random.random() < 0.7:
            name = skill_names[2]
            s = ALL_SKILLS[name]
            # 購入コストは0にする
            self.shop_offers.append({"name": name, "type": "SKILL", "j": 0, "g": 0, "desc": s["desc"]})
        else:
            j_amt = random.randint(3, 5)
            g_amt = random.randint(3, 5)
            self.shop_offers.append({"name": f"J{j_amt}/G{g_amt}", "type": "ITEM", "j": 0, "g": 0, "j_val": j_amt, "g_val": g_amt, "desc": "リソース補充"})

    def purchase_item(self, direction):
        """足元のアイテムを購入し、指定方向に割り当てて次の階へ"""
        if self.state != "SHOP": return
        
        item = None
        for i, pos in enumerate(self.shop_item_pos):
            if self.player_x == pos[0] and self.player_y == pos[1]:
                if i < len(self.shop_offers):
                    item = self.shop_offers[i]
                    break
        
        if not item: return
        
        # コストチェック
        cost_j = item["j"]
        cost_g = item["g"]
        if cost_j == -1: # 自爆などの全消費
            cost_j, cost_g = self.j, self.g
            
        if self.purchase_anim_timer > 0: return
        
        if self.j >= cost_j and self.g >= cost_g:
            self.j -= cost_j
            self.g -= cost_g
            
            if item["type"] == "SKILL":
                self.skills[direction] = item["name"]
            else:
                self.j += item.get("j_val", 0)
                self.g += item.get("g_val", 0)
                
            # 購入演出開始
            self.purchase_anim_timer = 0.5
            self.purchased_item_idx = i
            if self.se_heal: self.se_heal.play()
            
    def exit_shop_logic(self):
        """ショップを抜けて次の階層へ（実際の生成処理）"""
        self.play_bgm(self.bgm_main)
        self.floor += 1
        self.generate_level(start_pos=(self.player_x, self.player_y))
        self.state = "PLAYING"

    def exit_shop(self):
        """ショップを抜けて次の階層へ（アニメーション開始）"""
        self.start_transition(self.exit_shop_logic)

    def generate_level(self, start_pos):
        self.player_x, self.player_y = start_pos
        self.walls = set()
        self.enemies = []
        self.items = []
        self.exit_pos = None
        self.turns_left = 30
        if self.mode != "TIME_LIMIT":
            self.time_left = 30.0 # タイムリミット以外は30秒に戻す
        
        while True:
            ex = random.randint(0, GRID_SIZE-1)
            ey = random.randint(0, GRID_SIZE-1)
            if (ex, ey) != start_pos:
                self.exit_pos = (ex, ey)
                break
                
        num_walls = min(15, 2 + self.floor * 2)
        while len(self.walls) < num_walls:
            x, y = random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)
            if (x, y) != start_pos and (x, y) != self.exit_pos:
                self.walls.add((x, y))
                
        num_enemies = min(9, 1 + self.floor // 2)
        types = ["E1", "E2", "E3", "E4"]
        while len(self.enemies) < num_enemies:
            x, y = random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)
            etype = random.choice(types)
            if (x, y) != start_pos and (x, y) != self.exit_pos:
                # E3は壁上にもスポーン可能とする
                if etype == "E3" or (x, y) not in self.walls:
                    if not self.is_enemy_at(x, y):
                        self.enemies.append({"x": x, "y": y, "type": etype})
                        
        # JとGの配置
        num_items = max(2, 4 - self.floor // 4) # 階層が進むと少し減る
        attempts = 0
        while len(self.items) < num_items and attempts < 50:
            x, y = random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)
            if (x, y) != start_pos and (x, y) != self.exit_pos and (x, y) not in self.walls:
                if not self.is_enemy_at(x, y) and not any(i["x"]==x and i["y"]==y for i in self.items):
                    self.items.append({"x": x, "y": y, "type": random.choice(["J", "G"])})
            attempts += 1
            
        # フレーバーマスの配置
        self.flavor_tiles = {}
        flavor_candidates = []
        if self.floor >= 5:
            flavor_candidates.extend(["MINT"] * random.randint(0, 2))
            flavor_candidates.extend(["SODA"] * random.randint(0, 2))
        if self.floor >= 10:
            flavor_candidates.extend(["CARAMEL"] * random.randint(0, 1))
            flavor_candidates.extend(["POPPING"] * random.randint(0, 1))
            
        attempts = 0
        while flavor_candidates and attempts < 100:
            x, y = random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)
            # プレイヤー、出口、壁、敵、アイテム、既存のフレーバーマスと重ならないように
            if (x, y) != start_pos and (x, y) != self.exit_pos and (x, y) not in self.walls:
                if not self.is_enemy_at(x, y) and not any(i["x"]==x and i["y"]==y for i in self.items):
                    if (x, y) not in self.flavor_tiles:
                        flavor = flavor_candidates.pop()
                        self.flavor_tiles[(x, y)] = flavor
            attempts += 1

    def pool_enemy(self, e, dx=0, dy=0):
        """敵をプール（控室）へ送る（アニメーション付き）"""
        if e in self.enemies:
            self.enemies.remove(e)
            self.dropped_enemies += 1
            
            # 地表ワイプ (PiP) の上空から落とす演出
            self.pool_enemies.append({
                "x": random.uniform(20, 170), 
                "y": -50, # 画面外上空から
                "vx": random.uniform(-100, 100),
                "vy": random.uniform(400, 600), # 勢いよく落とす
                "type": e["type"],
                "phase": random.random() * math.pi * 2,
                "radius": 12, # 衝突判定用
                "eye_type": "NORMAL",
                "mood_timer": random.uniform(1.0, 4.0)
            })
            
            if self.se_blow: self.se_blow.play()
            
            # --- ボス出現演出チェック ---
            if self.dropped_enemies >= self.DROPPED_TO_BOSS and not self.boss_active and self.boss_intro_state is None:
                self.boss_intro_state = "MERGING"
                self.boss_intro_timer = 1.0 # 1秒間かけて中央へ吸い寄せ
                self.state = "BOSS_INTRO" # 演出専用状態へ
                return 
            
            # --- 吹き飛びアニメーションデータの追加 ---
            px = e["x"] * CELL_SIZE
            py = e["y"] * CELL_SIZE
            
            # 吹き飛ぶ方向を決定
            if dx == 0 and dy == 0:
                dx, dy = random.choice([(1,0),(-1,0),(0,1),(0,-1)])
                
            base_angle = math.atan2(dy, dx)
            angle_offset = random.uniform(-0.6, 0.6) # ランダムに角度をつける
            angle = base_angle + angle_offset
            
            speed = random.uniform(1000, 1500) # 初速 (px/s) ボンッと飛ぶ
            
            self.flying_enemies.append({
                "x": px, "y": py,
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "type": e["type"],
                "timer": 0.3, # 0.3秒間飛んで消滅
                "max_timer": 0.3,
                "cause": "DEAD"
            })

    def spawn_boss(self):
        """巨大ボスを出現させる"""
        self.state = "BOSS"
        self.boss_active = True
        self.boss_hp = 9 # 融合数に関わらずHPは9固定
        self.boss_max_hp = 9
        self.boss_size_cells = 3
        self.boss_x = 3 # 3x3の左上を (3,3) に配置 (グリッド中央付近)
        self.boss_y = 3
        self.boss_move_timer = 0
        self.boss_spawn_timer = 0 # 乱入タイマーをリセット
        self.screen_shake = 15.0 # 出現時に揺らす
        self.play_bgm(self.bgm_boss)
        
        # 既存の敵とトラップ、アイテムを全消去
        self.enemies = []
        self.items = []
        self.walls = set()
        self.exit_pos = None # ボス戦開始時は出口を消す
        self.dropped_enemies = 0 # カウントをリセット
        if self.mode != "TIME_LIMIT":
            self.time_left = 200.0 # ボス戦は200秒制限 (タイムリミット以外)
        
        # ボス出現用の演出（画面揺れなど）があればここでセット
        # プレイヤーを端に寄せるなどの安全策も検討
        if self.player_x >= 3 and self.player_x <= 5 and self.player_y >= 3 and self.player_y <= 5:
            # ボス出現範囲(3x3)の外側のどこかへランダムに退避させる
            candidates = [(x, y) for x in range(GRID_SIZE) for y in range(GRID_SIZE) if not (3 <= x <= 5 and 3 <= y <= 5)]
            self.player_x, self.player_y = random.choice(candidates)

    def pool_enemy_at(self, x, y, dx=0, dy=0):
        """指定座標の敵をプールへ送る"""
        for e in self.enemies:
            if e["x"] == x and e["y"] == y:
                self.pool_enemy(e, dx, dy)
                break

    def process_turn(self, dx, dy):
        if self.state not in ("PLAYING", "LOBBY", "BOSS"): return
        
        # 向きの更新
        if dx != 0 or dy != 0:
            self.player_facing_dx = dx
            self.player_facing_dy = dy
        
        self.is_sliding = False

        # POPPING の処理 (ターンの移動方向をランダムに上書き)
        if getattr(self, "popping_active", False):
            self.popping_active = False
            dx, dy = random.choice([(0,-1), (0,1), (-1,0), (1,0), (-1,-1), (1,-1), (-1,1), (1,1)])
            if self.se_move: self.se_move.play() # パチパチ発動音代わり

        # CARAMEL の処理 (ターン消費)
        if getattr(self, "caramel_stuck", False):
            self.caramel_stuck = False
            self.spin_anim_timer = 0.3
            if self.se_error: self.se_error.play() # 足が取られてる音
            
            # 泥（キャラメル）を振り払うパーティクル
            px, py = to_iso(self.player_x + 0.5, self.player_y + 0.5, 0)
            for _ in range(8):
                self.particles.append({
                    "x": px,
                    "y": py,
                    "vx": random.uniform(-100, 100),
                    "vy": random.uniform(-100, 100),
                    "life": 0.5,
                    "color": (210, 140, 70), # 茶色
                    "size": random.randint(3, 6)
                })
                
            self.total_turns_taken += 1
            self.end_player_turn() # 敵のターンへ
            return

        # 移動距離の決定
        dist = 1
        if self.jump_buff and self.state in ("PLAYING", "BOSS"):
            dist = 2
        
        # 跳躍バフはここで消費（1回の移動アクションでリセット）
        self.jump_buff = False
            
        nx, ny = self.player_x + dx * dist, self.player_y + dy * dist
        
        # フィールド外への移動制限 (ジャンプ時は着地地点)
        if not (0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE):
            if self.state in ("PLAYING", "BOSS"):
                self.trigger_gameover(dx, dy)
            return
            
        if self.state == "LOBBY":
            self.move_anim_dx = self.player_x - nx
            self.move_anim_dy = self.player_y - ny
            self.move_anim_timer = 0.075
            self.move_anim_max_timer = 0.075
            if self.se_move: self.se_move.play()
            self.player_x, self.player_y = nx, ny
            return
        
        if (nx, ny) in self.walls:
            if self.pierce_buff:
                self.walls.remove((nx, ny)) # 貫通で壁を壊す
                if self.se_pierce_break: self.se_pierce_break.play()
                
                # 壁が砕けるパーティクル演出
                px, py = to_iso(nx + 0.5, ny + 0.5, 15)
                for _ in range(12):
                    self.particles.append({
                        "x": px,
                        "y": py,
                        "vx": random.uniform(-250, 250),
                        "vy": random.uniform(-250, 250),
                        "life": 0.4,
                        "color": WALL_COLOR,
                        "size": random.randint(4, 10)
                    })
                    
                # 少し画面を揺らす
                self.screen_shake = 5.0
            else:
                self.attack_anim_dx = dx * dist
                self.attack_anim_dy = dy * dist
                self.attack_anim_timer = 0.15
                # 壁の「ぷるっ」と揺れる演出をセット
                self.wall_jiggles[(nx, ny)] = [0.3, dx, dy] # 0.3秒間、叩いた方向に揺らす
                if self.se_error: self.se_error.play()
                return # 壁なので進めない（E3が上にいても壁に阻まれて見逃される）
                
        # 敵への体当たり判定
        enemy_hit = None
        for e in self.enemies:
            if e["x"] == nx and e["y"] == ny:
                enemy_hit = e
                break
        
        if enemy_hit:
            self.pool_enemy(enemy_hit, dx, dy)
            self.attack_anim_dx = dx * dist
            self.attack_anim_dy = dy * dist
            self.attack_anim_timer = 0.15
        elif self.state == "BOSS" and self.is_boss_hit(nx, ny):
            # ボスへの体当たり攻撃
            self.damage_boss(1)
            self.attack_anim_dx = dx * dist
            self.attack_anim_dy = dy * dist
            self.attack_anim_timer = 0.15
        else:
            # 通常移動 / 跳躍移動
            self.move_anim_dx = -dx * dist
            self.move_anim_dy = -dy * dist
            self.move_anim_timer = 0.1 if dist == 2 else 0.075
            self.move_anim_max_timer = self.move_anim_timer
            if self.se_move: self.se_move.play()
            if dist == 2:
                if self.se_jump_move: self.se_jump_move.play() # 跳躍移動時のSEを短い専用のものに変更
            self.player_x = nx
            self.player_y = ny
        
        self.pierce_buff = False # 移動アクションによってバフは消費される
        self.total_turns_taken += 1
        # --- ターン終了処理 ---
        self.check_item_pickup()
        
        # --- フレーバーマスの発動 ---
        current_dx, current_dy = dx, dy
        while True:
            flavor = self.flavor_tiles.get((self.player_x, self.player_y))
            if not flavor: break
            
            if flavor == "MINT":
                next_x, next_y = self.player_x + current_dx, self.player_y + current_dy
                if not (0 <= next_x < GRID_SIZE and 0 <= next_y < GRID_SIZE):
                    self.trigger_gameover(current_dx, current_dy)
                    break
                elif (next_x, next_y) in self.walls:
                    self.wall_jiggles[(next_x, next_y)] = [0.3, current_dx, current_dy]
                    if self.se_error: self.se_error.play()
                    break
                elif self.is_enemy_at(next_x, next_y) or self.is_boss_hit(next_x, next_y):
                    if self.se_error: self.se_error.play()
                    break
                else:
                    # 現在の視覚的な座標を維持したまま、新しい目的地へのスライドを開始する
                    old_prog = 1.0 - (self.move_anim_timer / self.move_anim_max_timer) if self.move_anim_max_timer > 0 else 1.0
                    vis_x = self.player_x + self.move_anim_dx * (1.0 - old_prog)
                    vis_y = self.player_y + self.move_anim_dy * (1.0 - old_prog)
                    
                    self.player_x, self.player_y = next_x, next_y
                    self.move_anim_dx = vis_x - next_x
                    self.move_anim_dy = vis_y - next_y
                    self.move_anim_timer = 0.15
                    self.move_anim_max_timer = 0.15
                    
                    self.check_item_pickup()
                    self.is_sliding = True
                    continue
                    
            elif flavor == "SODA":
                self.jump_buff = True
                if self.se_pickup: self.se_pickup.play()
                del self.flavor_tiles[(self.player_x, self.player_y)]
                break
                    
            elif flavor == "CARAMEL":
                self.caramel_stuck = True
                self.j += 1
                if self.se_pickup: self.se_pickup.play()
                del self.flavor_tiles[(self.player_x, self.player_y)]
                break
                
            elif flavor == "POPPING":
                self.popping_active = True
                self.g += 1
                if self.se_pickup: self.se_pickup.play()
                del self.flavor_tiles[(self.player_x, self.player_y)]
                break
        
        # 移動アニメーションがある場合は、終了を待ってから敵のターンへ
        if self.move_anim_timer > 0:
            self.waiting_for_enemy_turn = True
        else:
            self.end_player_turn()

    def check_item_pickup(self):
        picked = [i for i in self.items if i["x"] == self.player_x and i["y"] == self.player_y]
        for i in picked:
            self.items.remove(i)
            if self.se_pickup: self.se_pickup.play()
            if i["type"] == "J":
                self.j += 1
            elif i["type"] == "G":
                self.g += 1

    def use_skill(self, direction):
        if self.state not in ("PLAYING", "BOSS"): return
        skill_name = self.skills.get(direction)
        skill_used = False
        
        if skill_name == "回復":
            if self.j >= 1 and self.g >= 1:
                self.j -= 1
                self.g -= 1
                self.hp = min(10, self.hp + 3)
                if self.se_heal: self.se_heal.play()
                # きらきらパーティクルの追加 (少し下げてプレイヤーに重ねる)
                for _ in range(12): # 少し増量
                    self.heal_particles.append({
                        "x": self.player_x * CELL_SIZE + CELL_SIZE // 2 + random.randint(-20, 20),
                        "y": self.player_y * CELL_SIZE + CELL_SIZE // 2 + random.randint(0, 25), # 下寄りに調整
                        "vx": 0,
                        "vy": 0,
                        "life": 1.2,
                        "size": random.randint(8, 16)
                    })
                # 回復量表示テキストの追加
                self.heal_texts.append({
                    "x": self.player_x * CELL_SIZE + CELL_SIZE // 2,
                    "y": self.player_y * CELL_SIZE,
                    "life": 1.5,
                    "text": "+3"
                })
                skill_used = True
        elif skill_name == "貫通":
            if self.g >= 1:
                self.g -= 1
                self.pierce_buff = True
                if self.se_pierce_charge: self.se_pierce_charge.play()
                skill_used = True
        elif skill_name == "回転":
            if self.j >= 2:
                self.j -= 2
                if self.se_spin: self.se_spin.play()
                skill_used = True
                self.spin_anim_timer = 0.3 # 0.3秒間回転するアニメーション
                
                # 周囲8マスにいる敵をすべて落とす
                targets = []
                boss_hit_flag = False
                for dx in [-1, 0, 1]:
                    for dy in [-1, 0, 1]:
                        if dx == 0 and dy == 0: continue
                        nx, ny = self.player_x + dx, self.player_y + dy
                        if self.is_boss_hit(nx, ny):
                            boss_hit_flag = True
                        for e in list(self.enemies):
                            if e["x"] == nx and e["y"] == ny:
                                targets.append(e)
                # 吹き飛ばす
                for e in targets:
                    push_dx = e["x"] - self.player_x
                    push_dy = e["y"] - self.player_y
                    self.pool_enemy(e, push_dx, push_dy)
                # ボスへのダメージ
                if boss_hit_flag:
                    self.damage_boss(1)
                    
        elif skill_name == "投擲":
            if self.j >= 1 and self.g >= 1:
                self.j -= 1
                self.g -= 1
                if self.se_throw: self.se_throw.play()
                # 最も近い直線上の敵を探す
                enemy_info = self.get_closest_enemy_info()
                if enemy_info:
                    e, dist, dx, dy = enemy_info
                    if e == "BOSS":
                        self.damage_boss(1)
                    else:
                        e["hit_by_throw"] = True
                        e["throw_dx"] = dx
                        e["throw_dy"] = dy
                    
                    # 投擲アニメーション用のデータ追加
                    self.throw_anim_timer = 0.2
                    self.throw_anim_dx = dx * dist
                    self.throw_anim_dy = dy * dist
                    skill_used = True
                    
        elif skill_name == "停止":
            if self.g >= 2:
                self.g -= 2
                self.stop_buff = 5
                if self.se_stop: self.se_stop.play()
                skill_used = True
        elif skill_name == "跳躍":
            if self.j >= 1:
                self.j -= 1
                self.jump_buff = True
                if self.se_poyo: self.se_poyo.play()
                skill_used = True
        elif skill_name == "重撃":
            if self.j >= 2 and self.g >= 5:
                self.j -= 2
                self.g -= 5
                # 最も近い直線上の敵を探す（演出用）
                enemy_info = self.get_closest_enemy_info()
                if enemy_info:
                    if self.se_heavy: self.se_heavy.play()
                    self.heavy_atk_timer = 0.6 # 0.6秒の往復アニメーション
                    self.heavy_atk_data = enemy_info
                    skill_used = True
        elif skill_name == "自爆":
            # 自爆は常に使用可能だが、コスト全消費
            self.j = 0
            self.g = 0
            self.hp = 1
            self.stop_bgm()
            # 演出タイマーセット
            self.bomb_flash_timer = 2.0
            skill_used = True
            # 直ちに敵を無効化（攻撃させない）
            self.stop_buff = 2.0

        if skill_used:
            # 1回きりのスキルなら即時消去
            if skill_name in ALL_SKILLS and ALL_SKILLS[skill_name]["once"]:
                self.skills[direction] = None
            
            # 貫通、跳躍、重撃は即時終了しない（重撃は演出終了時に呼び出す）
            if skill_name not in ["貫通", "跳躍", "重撃"]:
                self.end_player_turn()
        else:
            # リソース不足などの理由で使えなかった場合
            if self.se_error: self.se_error.play()

    def get_closest_enemy_info(self):
        """上下左右の直線上の一番近い敵の情報を返す"""
        closest_enemy = None
        closest_dist = 999
        closest_dx, closest_dy = 0, 0
        for dx, dy in [(0,1), (0,-1), (1,0), (-1,0)]:
            dist = 1
            while True:
                nx, ny = self.player_x + dx * dist, self.player_y + dy * dist
                if not (0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE): break
                if (nx, ny) in self.walls: break
                hit_enemy = None
                for e in self.enemies:
                    if e["x"] == nx and e["y"] == ny:
                        hit_enemy = e
                        break
                if hit_enemy:
                    if dist < closest_dist:
                        closest_dist = dist
                        closest_enemy = hit_enemy
                        closest_dx, closest_dy = dx, dy
                    break
                
                # ボスへのあたり判定
                if self.state == "BOSS" and self.is_boss_hit(nx, ny):
                    if dist < closest_dist:
                        closest_dist = dist
                        closest_enemy = "BOSS"
                        closest_dx, closest_dy = dx, dy
                    break
                    
                dist += 1
        if closest_enemy:
            return closest_enemy, closest_dist, closest_dx, closest_dy
        return None
                    
        if skill_used:
            self.end_player_turn()

    def next_level_logic(self):
        self.floor += 1
        
        # 実績解除チェック (検証用に5階に緩和中)
        if self.mode == "ENDLESS" and self.floor >= 5:
            if "ITEMLESS_ENDLESS" not in self.save_data.get("achievements", []):
                if "achievements" not in self.save_data: self.save_data["achievements"] = []
                self.save_data["achievements"].append("ITEMLESS_ENDLESS")
                SaveManager.save(self.save_data)
                self.itemless_unlocked = True

        self.generate_level(start_pos=(self.player_x, self.player_y))
        self.state = "PLAYING"

    def end_player_turn(self):
        """プレイヤーの行動終了後の処理（エネミーの移動など）"""
        if self.state in ("PLAYING", "BOSS"):
            # ボス戦以外ならターンを消費
            if self.state != "BOSS":
                self.turns_left -= 1
                if self.turns_left <= 0:
                    self.trigger_gameover(cause="DEAD")
            
            # 出口に到達したか
            if (self.player_x, self.player_y) == self.exit_pos:
                if self.mode == "TIME_ATTACK" and self.floor >= self.target_floor:
                    self.state = "GAMECLEAR"
                    self.cleartime = self.total_time
                    self.stop_bgm()
                    if self.se_start: self.se_start.play() # クリアのファンファーレ代わり
                    self.gameclear_selection = 0
                elif self.floor % 5 == 0 and self.mode != "ITEMLESS_ENDLESS":
                    self.start_transition(self.enter_shop)
                else:
                    self.start_transition(lambda: self.next_level_logic())
                return

            # --- ボスのターン処理 ---
            if self.state == "BOSS" and self.boss_active:
                if self.boss_transform_timer > 0: return # 変身中は動かない
                
                # --- エネミー乱入ロジック ---
                self.boss_spawn_timer += 1
                if self.boss_spawn_timer >= 10:
                    self.boss_spawn_timer = 0
                    etype = None
                    if self.DROPPED_TO_BOSS == 12: etype = "E2" # 2戦目: 猫
                    elif self.DROPPED_TO_BOSS == 15: etype = "E1" # 3戦目: 犬
                    elif self.DROPPED_TO_BOSS == 18: etype = "E4" # 4戦目以降: 牛
                    
                    if etype:
                        # スポーン可能な空きマスを探す
                        candidates = []
                        for x in range(GRID_SIZE):
                            for y in range(GRID_SIZE):
                                if (x, y) == (self.player_x, self.player_y): continue
                                if self.is_boss_hit(x, y): continue
                                if (x, y) in self.walls: continue
                                if self.is_enemy_at(x, y): continue
                                candidates.append((x, y))
                        
                        if candidates:
                            sx, sy = random.choice(candidates)
                            # スポーンアニメーション（ぷよん！）用のタイマーをセット
                            self.enemies.append({"x": sx, "y": sy, "type": etype, "spawn_timer": 0.5})
                            if self.se_poyo: self.se_poyo.play()
                            self.screen_shake = 5.0 # 降りてきた衝撃
                
                self.boss_move_timer += 1
                # サイズに応じて移動頻度を調整 (1x1なら毎ターン、2x2なら2ターン毎、3x3なら3ターン毎)
                move_thresh = 3
                if self.boss_size_cells == 2: move_thresh = 2
                elif self.boss_size_cells == 1: move_thresh = 1
                if self.boss_move_timer >= move_thresh:
                    self.boss_move_timer = 0
                    # プレイヤーの方へ近づく
                    # プレイヤーがボスの中心よりどちらにいるかで判定
                    bc_x = self.boss_x + self.boss_size_cells / 2.0
                    bc_y = self.boss_y + self.boss_size_cells / 2.0
                    bdx = 1 if self.player_x > bc_x else (-1 if self.player_x < bc_x else 0)
                    bdy = 1 if self.player_y > bc_y else (-1 if self.player_y < bc_y else 0)
                    
                    if bdx != 0 or bdy != 0:
                        self.boss_facing_dx = bdx
                        self.boss_facing_dy = bdy

                    # 移動先で壁があれば壊す

                    s = self.boss_size_cells
                    new_bx = max(0, min(GRID_SIZE - s, self.boss_x + bdx))
                    new_by = max(0, min(GRID_SIZE - s, self.boss_y + bdy))
                    for ox in range(s):
                        for oy in range(s):
                            if (new_bx + ox, new_by + oy) in self.walls:
                                self.walls.remove((new_bx + ox, new_by + oy))
                    
                    self.boss_x, self.boss_y = new_bx, new_by
                    
                # プレイヤーがボスに飲み込まれているか判定
                if self.is_boss_hit(self.player_x, self.player_y):
                    # フィールドのヘリ（端）に立っている場合は、弾き飛ばされずにそのまま落下
                    if self.player_x == 0 or self.player_x == GRID_SIZE - 1 or \
                       self.player_y == 0 or self.player_y == GRID_SIZE - 1:
                        # 弾き飛ばしベクトルを計算して、1マス場外にずらす
                        bcx, bcy = self.boss_x + self.boss_size_cells / 2.0, self.boss_y + self.boss_size_cells / 2.0
                        pdx, pdy = self.player_x - bcx, self.player_y - bcy
                        sx = 1 if pdx > 0 else (-1 if pdx < 0 else 0)
                        sy = 1 if pdy > 0 else (-1 if pdy < 0 else 0)
                        if sx == 0 and sy == 0: sx, sy = random.choice([(1,0),(-1,0),(0,1),(0,-1)])
                        self.trigger_gameover(dx=sx, dy=sy, cause="FALL")
                        return

                    self.hp -= 2 # ボスからのダメージ
                    self.damage_face_timer = 0.5 # イテテ
                    self.screen_shake = 8.0
                    if self.se_damage: self.se_damage.play()

                    if self.hp <= 0:
                        self.trigger_gameover(cause="DEAD")
                        return
                    
                    # --- 放射状の弾き飛ばし処理 ---
                    # ボスの中心 (boss_x+1, boss_y+1) からプレイヤーへのベクトルを計算
                    bcx, bcy = self.boss_x + 1, self.boss_y + 1
                    pdx, pdy = self.player_x - bcx, self.player_y - bcy
                    
                    # プレイヤーがボスの真ん中にいる場合はランダムな方向へ
                    if pdx == 0 and pdy == 0:
                        pdx, pdy = random.choice([(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)])
                    
                    # ベクトルの方向に、ボスの3x3圏外になるまで座標を進める
                    # 2〜3マスの余裕を持って外側へ逃がす
                    found = False
                    for dist in range(1, 6):
                        sx = 1 if pdx > 0 else (-1 if pdx < 0 else 0)
                        sy = 1 if pdy > 0 else (-1 if pdy < 0 else 0)
                        tx, ty = self.player_x + sx * dist, self.player_y + sy * dist
                        
                        # フィールド外なら落下
                        if not (0 <= tx < GRID_SIZE and 0 <= ty < GRID_SIZE):
                            # 移動先 tx, ty (場外) へオフセットを渡す
                            self.trigger_gameover(dx=sx*dist, dy=sy*dist, cause="FALL")
                            return
                            
                        # ボスの3x3圏外ならそこに決定
                        if not self.is_boss_hit(tx, ty):
                            # アニメーション設定 (吹き飛ぶ演出)
                            self.pushback_anim_dx = self.player_x - tx
                            self.pushback_anim_dy = self.player_y - ty
                            self.pushback_anim_timer = 0.15
                            self.player_x, self.player_y = tx, ty
                            found = True
                            break
                    
                    # もし万が一場所が見つからなかった場合の安全策
                    if not found:
                        self.player_x, self.player_y = 0, 0 # 端へ逃がす
                # return # <-- 乱入エネミーを動かすために削除

            # --- 敵のターン処理（通常フロア） ---
            if self.stop_buff > 0:
                self.stop_buff -= 1
                return
            
        # --- 敵のターン処理 ---
        if self.stop_buff > 0:
            self.stop_buff -= 1
            return # 敵のターンをスキップ（自機ターン終了処理は行う）
            
        for e in list(self.enemies):
            if e not in self.enemies or self.state not in ("PLAYING", "BOSS") or e.get("hit_by_throw"): continue
            
            ex, ey = e["x"], e["y"]
            target_x, target_y = ex, ey
            
            # AI挙動分岐
            if e["type"] in ["E1", "E4"]:
                # 追尾型
                ex_dx = 1 if self.player_x > ex else (-1 if self.player_x < ex else 0)
                ex_dy = 1 if self.player_y > ey else (-1 if self.player_y < ey else 0)
                
                moves = []
                if ex_dx != 0: moves.append(("X", ex_dx, 0))
                if ex_dy != 0: moves.append(("Y", 0, ex_dy))
                random.shuffle(moves)
                
                for axis, dx, dy in moves:
                    if (ex+dx, ey+dy) not in self.walls and not self.is_enemy_at(ex+dx, ey+dy) and not self.is_boss_hit(ex+dx, ey+dy):
                        target_x, target_y = ex+dx, ey+dy
                        break
            elif e["type"] == "E2":
                # 猫型（ランダム）
                dirs = [(0,1), (0,-1), (1,0), (-1,0)]
                random.shuffle(dirs)
                for dx, dy in dirs:
                    if 0 <= ex+dx < GRID_SIZE and 0 <= ey+dy < GRID_SIZE:
                        if (ex+dx, ey+dy) not in self.walls and not self.is_enemy_at(ex+dx, ey+dy) and not self.is_boss_hit(ex+dx, ey+dy):
                            target_x, target_y = ex+dx, ey+dy
                            break
            elif e["type"] == "E3":
                # ウサギ型（壁を越える）
                ex_dx = 1 if self.player_x > ex else (-1 if self.player_x < ex else 0)
                ex_dy = 1 if self.player_y > ey else (-1 if self.player_y < ey else 0)
                
                moves = []
                if ex_dx != 0: moves.append(("X", ex_dx, 0))
                if ex_dy != 0: moves.append(("Y", 0, ex_dy))
                random.shuffle(moves)
                
                for axis, dx, dy in moves:
                    if not self.is_enemy_at(ex+dx, ey+dy) and not self.is_boss_hit(ex+dx, ey+dy):
                        target_x, target_y = ex+dx, ey+dy
                        break
                    
            # プレイヤーへの攻撃判定
            if target_x == self.player_x and target_y == self.player_y:
                # 敵の攻撃アニメーション設定
                e["atk_dx"] = target_x - ex
                e["atk_dy"] = target_y - ey
                e["atk_timer"] = 0.15
                
                # プレイヤーへの視覚的な「押し」演出
                self.visual_push_timer = 0.15
                self.visual_push_dx = e["atk_dx"]
                self.visual_push_dy = e["atk_dy"]
                
                if self.bomb_flash_timer <= 0:
                    self.hp -= 1
                    self.damage_face_timer = 0.5
                    if self.se_damage: self.se_damage.play()
                if self.hp <= 0:
                    self.trigger_gameover(e["atk_dx"], e["atk_dy"], cause="DEAD")
                
                # E4のプレイヤーノックバック追加効果
                if e["type"] == "E4" and self.state == "PLAYING":
                    push_dx, push_dy = target_x - ex, target_y - ey
                    px, py = self.player_x + push_dx, self.player_y + push_dy
                    
                    self.pushback_anim_dx = -push_dx
                    self.pushback_anim_dy = -push_dy
                    self.pushback_anim_timer = 0.15
                    self.move_anim_timer = 0.0 # ノックバック優先
                    
                    if not (0 <= px < GRID_SIZE and 0 <= py < GRID_SIZE):
                        self.trigger_gameover(push_dx, push_dy)
                    elif (px, py) in self.walls:
                        self.walls.remove((px, py)) # Pが壁を破壊
                        self.hp -= 1                # 激突で追加ダメージ
                        self.damage_face_timer = 0.5
                        if self.se_damage: self.se_damage.play()
                        self.player_x, self.player_y = px, py
                    elif self.is_enemy_at(px, py):
                        self.pool_enemy_at(px, py, push_dx, push_dy)  # Pが敵を押し潰す
                        self.hp -= 1                # 激突で追加ダメージ
                        self.damage_face_timer = 0.5
                        if self.se_damage: self.se_damage.play()
                        self.player_x, self.player_y = px, py
                    else:
                        self.player_x, self.player_y = px, py
                        
                    if self.hp <= 0:
                        self.trigger_gameover(push_dx, push_dy, cause="DEAD")
            else:
                if target_x != ex or target_y != ey:
                    e["move_dx"] = ex - target_x
                    e["move_dy"] = ey - target_y
                    e["move_timer"] = 0.075
                    e["facing_dx"] = target_x - ex
                    e["facing_dy"] = target_y - ey
                e["x"] = target_x
                e["y"] = target_y
                
        self.check_item_pickup()

    def damage_boss(self, amount):
        """ボスにダメージを与え、フェーズ移行を管理する"""
        if self.state != "BOSS": return
        # 変身中は無敵またはダメージ無効
        if self.boss_transform_timer > 0: return
        
        self.boss_hp -= amount
        self.boss_damage_timer = 0.5
        self.screen_shake = 5.0 + amount * 0.5
        if self.se_damage: self.se_damage.play()
        
        # フェーズ移行: HP 4 以下で 2x2 に縮小（演出開始）
        if self.boss_hp <= 4 and self.boss_size_cells == 3:
            self.boss_transform_timer = 0.5 # 0.5秒の溜め
            self.screen_shake = 25.0
            if self.se_bomb: self.se_bomb.play()
            
            # パーティクル生成 (白い煙を多めに)
            bcx, bcy = to_iso(self.boss_x + 1.5, self.boss_y + 1.5, 20)
            for _ in range(30):
                self.particles.append({
                    "x": bcx, "y": bcy,
                    "vx": random.uniform(-200, 200),
                    "vy": random.uniform(-200, 200),
                    "life": 1.0, "size": random.randint(5, 15)
                })
                
        # フェーズ移行2: HP 1 で 1x1 に縮小 (さらに悪あがき)
        if self.boss_hp <= 1 and self.boss_size_cells == 2:
            self.boss_transform_timer = 0.5
            self.screen_shake = 30.0
            if self.se_bomb: self.se_bomb.play()
            bcx, bcy = to_iso(self.boss_x + 1.0, self.boss_y + 1.0, 10)
            for _ in range(20):
                self.particles.append({
                    "x": bcx, "y": bcy,
                    "vx": random.uniform(-300, 300),
                    "vy": random.uniform(-300, 300),
                    "life": 0.8, "size": random.randint(3, 10)
                })
                
        if self.boss_hp <= 0:
            self.check_boss_defeat()

    def is_enemy_at(self, x, y):
        return any(e["x"] == x and e["y"] == y for e in self.enemies)

    def is_boss_hit(self, x, y):
        """指定座標がボスのサイズ圏内かチェック"""
        if self.state != "BOSS" or not self.boss_active: return False
        s = self.boss_size_cells
        return self.boss_x <= x < self.boss_x + s and self.boss_y <= y < self.boss_y + s

    def check_boss_defeat(self):
        """ボスの撃破判定"""
        if self.boss_hp <= 0:
            self.boss_active = False
            self.dropped_enemies = 0 # リセットしてまた遊べるように
            self.DROPPED_TO_BOSS = min(18, self.DROPPED_TO_BOSS + 3) # 次回までの必要数を+3 (上限18)
            if self.se_next: self.se_next.play()
            self.play_bgm(self.bgm_main)
            self.exit_pos = (4, 0) # 上部中央に出口を出現
            
            # ボスグミをプールに追加
            self.pool_enemies.append({
                "x": 96, "y": -50,
                "vx": 0, "vy": 600,
                "type": "BOSS",
                "phase": 0, "radius": 15
            })

    def update_time(self, dt):
        # --- ワイプ演出の更新 ---
        # 演出中は他の一切の計算をスキップして負荷を最小限にする
        if self.wipe_active:
            old_w = self.wipe_timer
            self.wipe_timer += dt
            # 0.8秒付近で全画面が覆われる計算
            if old_w < 0.7 and self.wipe_timer >= 0.7:
                if self.wipe_callback:
                    self.wipe_callback()
                    self.wipe_callback = None
            if self.wipe_timer > 1.5:
                self.wipe_active = False
                if self.state == "WAITING_FOR_WIPE":
                    self.play_bgm(self.bgm_main)
                    self.state = "COUNTDOWN"
                    self.countdown_timer = 2.99
            return
        
        # --- ゲームオーバー後演出の更新 ---
        if self.state in ("GAMEOVER_RETRY_ANIM", "GAMEOVER_TITLE_ANIM"):
            self.gameover_anim_timer -= dt
            if self.gameover_anim_timer <= 0:
                self.needs_reset = self.state
            
            # 演出中も物理演算（グミの落下など）は動かす
            if self.stop_buff <= 0:
                self.update_pool_physics(dt)
                for pe in self.pool_enemies:
                    pe["phase"] += dt * 5.0
            return # 演出中は他の更新を止める
            
        if self.state == "GAMEOVER":
            if random.random() < dt * 15: # 毎秒約15匹のグミを降らせる
                self.pool_enemies.append({
                    "x": random.uniform(20, 170), 
                    "y": -50,
                    "vx": random.uniform(-50, 50),
                    "vy": random.uniform(200, 500),
                    "type": f"E{random.randint(1, 3)}",
                    "phase": random.random() * math.pi * 2,
                    "radius": 15
                })
            
            # パフォーマンス維持とクラッシュ防止のため、グミが100匹を超えたら古いものから削除
            if len(self.pool_enemies) > 100:
                for idx, pe in enumerate(self.pool_enemies):
                    if pe.get("type") != "PLAYER":
                        self.pool_enemies.pop(idx)
                        break

        # --- 落下消滅演出の更新 ---
        if self.state == "DYING":
            self.dying_timer -= dt
            
            # HP0時は敵と同じく0.3秒間フィールド上で吹き飛ぶ
            if self.death_cause == "DEAD" and self.dying_timer > 0.3:
                self.death_px += self.death_vx * dt
                self.death_py += self.death_vy * dt

            if self.dying_timer <= 0:
                self.state = "GAMEOVER"
                self.move_anim_timer = 0.0
                self.gameover_selection = 0 # 0: リトライ, 1: タイトル, 2: 共有
                
                # HP0(DEAD)の場合は既に trigger_gameover で追加済みなのでスキップ
                if self.death_cause != "DEAD":
                    # --- 地表ワイプ（エネミープール）へプレイヤーを落とす実体を追加 ---
                    self.pool_enemies.append({
                        "x": random.uniform(20, 170), 
                        "y": -50, # 画面外上空から
                        "vx": random.uniform(-50, 50),
                        "vy": random.uniform(600, 800), # 勢いよく落とす
                        "type": "PLAYER",
                        "phase": 0,
                        "radius": 15,
                        "eye_type": "NORMAL",
                        "mood_timer": random.uniform(1.0, 4.0)
                    })
            return # 演出中は他のメインロジックの更新を止める
        # --- 変身演出・パーティクルの更新 ---
        if self.boss_transform_timer > 0:
            old_timer = self.boss_transform_timer
            self.boss_transform_timer = max(0, self.boss_transform_timer - dt)
            if old_timer > 0 and self.boss_transform_timer <= 0:
                # 演出終了の瞬間に実際のサイズダウンと接近を実行
                if self.boss_size_cells == 3:
                    self.boss_size_cells = 2
                    # プレイヤーに近い方へ寄せる
                    if self.player_x > self.boss_x + 1:
                        self.boss_x = min(GRID_SIZE - 2, self.boss_x + 1)
                    if self.player_y > self.boss_y + 1:
                        self.boss_y = min(GRID_SIZE - 2, self.boss_y + 1)
                elif self.boss_size_cells == 2:
                    self.boss_size_cells = 1
                    # プレイヤーの近くにワープ
                    self.boss_x = max(0, min(GRID_SIZE - 1, self.player_x + random.choice([-1, 1])))
                    self.boss_y = max(0, min(GRID_SIZE - 1, self.player_y + random.choice([-1, 1])))
        
        # --- 壁の揺れ演出タイマーの更新 ---
        for pos in list(self.wall_jiggles.keys()):
            self.wall_jiggles[pos][0] -= dt
            if self.wall_jiggles[pos][0] <= 0:
                del self.wall_jiggles[pos]
        
        # --- ショップ購入演出の更新 ---
        if self.purchase_anim_timer > 0:
            old_p = self.purchase_anim_timer
            self.purchase_anim_timer -= dt
            if old_p > 0 and self.purchase_anim_timer <= 0:
                self.shop_offers = [] # 商品リストを空にしてから遷移（残像防止）
                self.exit_shop()
        
        for pos in list(self.tile_jiggles.keys()):
            self.tile_jiggles[pos] -= dt
            if self.tile_jiggles[pos] <= 0:
                del self.tile_jiggles[pos]

        for p in list(self.particles):
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["life"] -= dt * 2.0 # 0.5秒で消える
            if p["life"] <= 0:
                self.particles.remove(p)
                
        # --- 回復キラキラパーティクルの更新 ---
        for hp in list(self.heal_particles):
            hp["x"] += hp["vx"] * dt
            hp["y"] += hp["vy"] * dt
            hp["life"] -= dt * 1.5
            if hp["life"] <= 0:
                self.heal_particles.remove(hp)
                
        # --- 回復量表示テキストの更新 ---
        for ht in list(self.heal_texts):
            # y移動は collect_floor_tasks 内の z 座標で行うためここでは不要
            ht["life"] -= dt
            if ht["life"] <= 0:
                self.heal_texts.remove(ht)
                
        # --- 自爆演出の更新 ---
        if self.bomb_flash_timer > 0:
            old_timer = self.bomb_flash_timer
            self.bomb_flash_timer -= dt
            # 1.0秒経過の瞬間に爆発音と一掃処理を行う
            if old_timer > 1.0 and self.bomb_flash_timer <= 1.0:
                self.screen_shake = 30.0
                if self.se_bomb: self.se_bomb.play()
                self.play_bgm(self.bgm_main)
                # 実際の敵消去・ダメージ処理
                if self.state == "BOSS":
                    self.damage_boss(25)
                for e in list(self.enemies):
                    dx = 1 if e["x"] > self.player_x else (-1 if e["x"] < self.player_x else 0)
                    dy = 1 if e["y"] > self.player_y else (-1 if e["y"] < self.player_y else 0)
                    self.pool_enemy(e, dx, dy)
                
        # --- 重撃演出の更新 ---
        if self.heavy_atk_timer > 0:
            old_timer = self.heavy_atk_timer
            self.heavy_atk_timer -= dt
            # 中間地点 (0.3s) で着地・ダメージ
            if old_timer > 0.3 and self.heavy_atk_timer <= 0.3:
                e, dist, dx, dy = self.heavy_atk_data
                if e == "BOSS":
                    self.damage_boss(9)
                else:
                    self.pool_enemy(e, dx, dy)
                if self.se_damage: self.se_damage.play()
                self.screen_shake = 10.0
                
            if old_timer > 0 and self.heavy_atk_timer <= 0:
                self.end_player_turn()
                
        # --- ボス出現演出シーケンスの更新 ---
        if getattr(self, "boss_intro_state", None):
            self.boss_intro_timer -= dt
            if self.boss_intro_state == "MERGING":
                # 全員をワイプ内の中心（ローカル座標 96, 96）へ吸引
                cx, cy = 96, 96
                for pe in self.pool_enemies:
                    dx, dy = cx - pe["x"], cy - pe["y"]
                    dist = math.sqrt(dx*dx + dy*dy) or 1
                    
                    # 吸引力
                    pe["vx"] += dx * 25 * dt
                    pe["vy"] += dy * 25 * dt
                    
                    # 渦巻き成分（円運動を加える）
                    v_speed = 700
                    pe["vx"] += (dy / dist) * v_speed * dt
                    pe["vy"] -= (dx / dist) * v_speed * dt
                    
                    # ランダムな微振動（合体前のエネルギー感）
                    pe["vx"] += random.uniform(-600, 600) * dt
                    pe["vy"] += random.uniform(-600, 600) * dt
                    
                    pe["vx"] *= 0.85
                    pe["vy"] *= 0.85
                
                # 合体の瞬間 (残り0.2秒)
                if self.boss_intro_timer <= 0.2:
                    # 既に大きなボス(radius=40)が集約済みかどうかで判定
                    # 前回撃破後の小さなボス(radius=15)がプールにいても、ここで巨大ボスに上書きする
                    is_merged = any(pe.get("type") == "BOSS" and pe.get("radius") == 40 for pe in self.pool_enemies)
                    
                    if not is_merged:
                        self.pool_enemies = [{
                            "x": 96, "y": 96, "vx": 0, "vy": 0, "type": "BOSS",
                            "phase": 0, "radius": 40, "eye_type": "NORMAL", "mood_timer": 2.0
                        }]
                        if self.se_bomb: self.se_bomb.play()
                    else:
                        # 既に大きなボスがいる場合、それ以外のグミがあれば吸収し続ける
                        self.pool_enemies = [pe for pe in self.pool_enemies if pe.get("type") == "BOSS" and pe.get("radius") == 40]
                
                if self.boss_intro_timer <= 0:
                    self.boss_intro_state = "LEAPING"
                    self.boss_intro_timer = 0.6 # 少し長めに飛ぶ
                    if self.se_jump: self.se_jump.play()
            elif self.boss_intro_state == "LEAPING":
                # ボスを上空へ猛スピードで飛ばす
                for pe in self.pool_enemies:
                    if pe.get("type") == "BOSS":
                        pe["vy"] = -2500 # さらに高速に！
                        pe["vx"] = 0
                
                if self.boss_intro_timer <= 0:
                    self.boss_intro_state = "FALLING"
                    self.boss_intro_timer = 0.8 # 上空で一瞬待ってから降ってくる
            elif self.boss_intro_state == "FALLING":
                if self.boss_intro_timer <= 0:
                    self.boss_intro_state = "BLASTING"
                    self.boss_intro_timer = 0.3
                    self.screen_shake = 30.0
                    if self.se_damage: self.se_damage.play()
                    
                    # --- 周囲の実体を吹き飛ばす (REAL BLAST) ---
                    center_x, center_y = 400, 350 # 中央 (影の位置に合わせる)
                    
                    # 敵を吹き飛ばす
                    for e in self.enemies:
                        # 表示上の左上位置 (x, y)
                        lx, ly = e["x"] * CELL_SIZE, e["y"] * CELL_SIZE
                        # 爆風の方向計算用（タイルの中心）
                        ex, ey = GRID_OFFSET_X + lx + 20, GRID_OFFSET_Y + ly + 20
                        
                        dx, dy = ex - center_x, ey - center_y
                        dist = math.sqrt(dx*dx + dy*dy) or 1
                        speed = random.uniform(800, 1500)
                        self.flying_enemies.append({
                            "x": lx, "y": ly, 
                            "vx": (dx/dist) * speed, "vy": (dy/dist) * speed,
                            "type": e["type"], "timer": 0.5, "max_timer": 0.5, "cause": "DEAD"
                        })

                    # 壁を吹き飛ばす
                    for (wx, wy) in self.walls:
                        lx, ly = wx * CELL_SIZE, wy * CELL_SIZE
                        ex, ey = GRID_OFFSET_X + lx + 20, GRID_OFFSET_Y + ly + 20
                        
                        dx, dy = ex - center_x, ey - center_y
                        dist = math.sqrt(dx*dx + dy*dy) or 1
                        speed = random.uniform(600, 1200)
                        self.flying_enemies.append({
                            "x": lx, "y": ly, 
                            "vx": (dx/dist) * speed, "vy": (dy/dist) * speed,
                            "type": "WALL", "timer": 0.5, "max_timer": 0.5, "cause": "DEAD"
                        })

                    # アイテムを吹き飛ばす
                    for it in self.items:
                        lx, ly = it["x"] * CELL_SIZE, it["y"] * CELL_SIZE
                        dx, dy = ex - center_x, ey - center_y
                        dist = math.sqrt(dx*dx + dy*dy) or 1
                        speed = random.uniform(700, 1300)
                        self.flying_enemies.append({
                            "x": lx, "y": ly, 
                            "vx": (dx/dist) * speed, "vy": (dy/dist) * speed,
                            "type": "ITEM_" + it["type"], "timer": 0.5, "max_timer": 0.5, "cause": "DEAD"
                        })

                    self.spawn_boss()
                    self.pool_enemies = [] # プールを空に
            elif self.boss_intro_state == "BLASTING":
                if self.boss_intro_timer <= 0:
                    self.boss_intro_state = None # 演出終了
            
            # 演出中も物理演算は動かす
            if self.boss_intro_state in ("MERGING", "LEAPING"):
                self.update_pool_physics(dt)
            return

        # ----------------------------------------------------
        # プールの物理演算更新 (停止中は停止)
        if self.stop_buff <= 0:
            self.update_pool_physics(dt)
            for pe in self.pool_enemies:
                pe["phase"] += dt * 5.0
        # ----------------------------------------------------

        if self.screen_shake > 0:
            self.screen_shake -= dt * 40 # 素早く減衰
            if self.screen_shake < 0: self.screen_shake = 0

        # ゲームオーバーSEの遅延再生
        if self.fail_sound_timer > 0:
            old_timer = self.fail_sound_timer
            self.fail_sound_timer -= dt
            if old_timer > 0 and self.fail_sound_timer <= 0:
                if self.se_fail: self.se_fail.play()

        if self.state == "COUNTDOWN":
            self.countdown_timer -= dt * 1.5 # 少し速めにカウントダウン
            if self.countdown_timer <= 0:
                self.state = "PLAYING"
                
        if self.state in ("PLAYING", "BOSS", "SHOP"):
            self.time_left -= dt
            self.total_time += dt
            
            if self.time_left <= 0:
                if self.mode == "TIME_LIMIT":
                    self.state = "GAMECLEAR"
                    self.cleartime = self.total_time
                    self.stop_bgm()
                    if self.se_start: self.se_start.play()
                    self.gameclear_selection = 0
                else:
                    self.trigger_gameover(cause="DEAD")
                return

        if self.state == "SHOP":
            self.shop_timer -= dt
            if self.shop_timer <= 0:
                self.exit_shop()
                
        if self.attack_anim_timer > 0:
            self.attack_anim_timer -= dt
            
        if self.pushback_anim_timer > 0:
            self.pushback_anim_timer -= dt
            
        if self.move_anim_timer > 0:
            self.move_anim_timer -= dt
            if self.move_anim_timer <= 0:
                self.move_anim_timer = 0
                if self.waiting_for_enemy_turn:
                    self.waiting_for_enemy_turn = False
                    self.end_player_turn()
                
                # ロビーでのタイルイベント（移動完了後に発動させる）
                if self.state == "LOBBY":
                    if (self.player_x, self.player_y) == self.lobby_start_pos:
                        self.mode = "ENDLESS"
                        self.start_countdown()
                    elif (self.player_x, self.player_y) == self.time_attack_start_pos:
                        self.mode = "TIME_ATTACK"
                        self.state = "LOBBY_MENU"
                    elif (self.player_x, self.player_y) == self.time_limit_start_pos:
                        self.mode = "TIME_LIMIT"
                        self.state = "LOBBY_LIMIT_MENU"
                    # elif self.itemless_unlocked and (self.player_x, self.player_y) == self.itemless_start_pos:
                    #     self.mode = "ITEMLESS_ENDLESS"
                    #     # アイテムレス・初期化
                    #     self.hp = 20
                    #     self.j = 0
                    #     self.g = 0
                    #     self.skills = {"UP": None, "RIGHT": None, "DOWN": None, "LEFT": None}
                    #     self.start_countdown()
            
        if self.spin_anim_timer > 0:
            self.spin_anim_timer -= dt
            
        if self.throw_anim_timer > 0:
            self.throw_anim_timer -= dt
            if self.throw_anim_timer <= 0:
                for e in list(self.enemies):
                    if e.get("hit_by_throw"):
                        dx, dy = e["throw_dx"], e["throw_dy"]
                        self.pool_enemy(e, dx, dy)
        
        if getattr(self, "wait_anim_timer", 0) > 0:
            self.wait_anim_timer -= dt
            
        # --- 停止中のビープ音再生ロジック ---
        if self.stop_buff > 0 and self.state in ("PLAYING", "BOSS"):
            self.stop_beep_timer += dt
            if self.stop_beep_timer >= 1.0: # 1秒おき
                self.stop_beep_timer = 0.0
                if self.se_stop_beep: self.se_stop_beep.play()
        else:
            self.stop_beep_timer = 0.0
            
        if getattr(self, "visual_push_timer", 0) > 0:
            self.visual_push_timer -= dt

        if self.damage_face_timer > 0:
            self.damage_face_timer -= dt
            
        if getattr(self, "boss_damage_timer", 0) > 0:
            self.boss_damage_timer -= dt
            
        for e in self.enemies:
            if e.get("atk_timer", 0) > 0:
                e["atk_timer"] -= dt
            if e.get("move_timer", 0) > 0:
                e["move_timer"] -= dt
            if e.get("spawn_timer", 0) > 0:
                e["spawn_timer"] -= dt
            
        for f in list(self.flying_enemies):
            f["x"] += f["vx"] * dt
            f["y"] += f["vy"] * dt
            f["timer"] -= dt
            if f["timer"] <= 0:
                self.flying_enemies.remove(f)

        # 階層移動トランジションの更新 (スライド演出)
        if self.transition_direction == -1:
            self.transition_timer -= dt * 2.0 # 0.5秒で上から来る
            if self.transition_timer <= 0:
                self.transition_timer = 0.0
                self.transition_direction = 0
                # 着地時のバウンド演出をトリガー
                self.landing_jiggle_timer = 0.3
                self.scroll_timer = 0.4 # 0.4秒かけてスクロール
                self.screen_shake = 20.0 # 着地の衝撃 (より強く)
                if self.se_land: self.se_land.play()
                if self.se_puff: self.se_puff.play()
                if self.se_move: self.se_move.play()
                
                # 着地時の砂埃エフェクト (量を増やす)
                for _ in range(50):
                    rx = random.randint(0, GRID_SIZE - 1)
                    ry = random.randint(0, GRID_SIZE - 1)
                    px, py = to_iso(rx + 0.5, ry + 0.5, 0)
                    self.particles.append({
                        "x": px, "y": py,
                        "vx": random.uniform(-150, 150), "vy": random.uniform(-150, 150),
                        "life": random.uniform(0.4, 0.7), "color": (210, 210, 190), "size": random.randint(5, 10)
                    })
                
        if self.landing_jiggle_timer > 0:
            self.landing_jiggle_timer -= dt
            
        if self.scroll_timer > 0:
            self.scroll_timer -= dt
            if self.scroll_timer < 0: self.scroll_timer = 0

    def update_pool_physics(self, dt):
        """地表ワイプ内の敵の物理演算（PiPウィンドウ内での衝突判定）"""
        # ワイプの内部サイズ (192x192)
        iw = 192
        ih = 192
        gravity = 1200
        
        for i, pe in enumerate(self.pool_enemies):
            is_leaping_boss = (pe.get("type") == "BOSS" and getattr(self, "boss_intro_state", None) == "LEAPING")
            
            # 表情タイマーの更新 (属性がない場合は初期化)
            if "mood_timer" not in pe:
                pe["mood_timer"] = random.uniform(1.0, 4.0)
            if "eye_type" not in pe:
                pe["eye_type"] = "NORMAL"

            pe["mood_timer"] -= dt
            if pe["mood_timer"] <= 0:
                if pe["eye_type"] == "NORMAL":
                    # 次の表情をランダムに決定
                    pe["eye_type"] = random.choice(["FLAT", "SQUEEZE"])
                    pe["mood_timer"] = random.uniform(0.5, 1.2) # 表情維持時間
                else:
                    # 通常に戻る
                    pe["eye_type"] = "NORMAL"
                    pe["mood_timer"] = random.uniform(1.5, 4.5) # 通常の維持時間
            
            # 重力 (演出中のボスは無重力)
            if not is_leaping_boss:
                pe["vy"] += gravity * dt
            
            # 移動
            pe["x"] += pe["vx"] * dt
            pe["y"] += pe["vy"] * dt
            
            # 地面・壁との衝突 (演出中のボスは無視)
            if is_leaping_boss:
                continue
            ground_y = ih - 30
            if pe["y"] + pe["radius"] >= ground_y:
                pe["y"] = ground_y - pe["radius"]
                # 接地時の跳ね返り
                if abs(pe["vy"]) < 100 and random.random() < 0.01:
                    pe["vy"] = -random.uniform(400, 600)
                    pe["vx"] += random.uniform(-150, 150)
                else:
                    pe["vy"] = -abs(pe["vy"]) * 0.2
                pe["vx"] *= 0.8 # 摩擦
                
            # 左右の壁との衝突 (0〜iw)
            if pe["x"] - pe["radius"] < 0:
                pe["x"] = pe["radius"]
                pe["vx"] = abs(pe["vx"]) * 0.4
            elif pe["x"] + pe["radius"] > iw:
                pe["x"] = iw - pe["radius"]
                pe["vx"] = -abs(pe["vx"]) * 0.4
                
            # 他の敵との衝突 (最適化: 距離の2乗で先行判定 & ペア間引き)
            frame_idx = int(self.total_time * 60)
            for j in range(i + 1, len(self.pool_enemies)):
                # 全ペアの半分を毎フレーム交互に処理して負荷軽減
                if (i + j + frame_idx) % 2 != 0: continue
                
                other = self.pool_enemies[j]
                dx = other["x"] - pe["x"]
                dy = other["y"] - pe["y"]
                dist_sq = dx*dx + dy*dy
                min_dist = pe["radius"] + other["radius"]
                
                if dist_sq < min_dist * min_dist and dist_sq > 0:
                    dist = math.sqrt(dist_sq)
                    # 押し出す
                    overlap = min_dist - dist
                    nx, ny = dx / dist, dy / dist
                    pe["x"] -= nx * overlap * 0.5
                    pe["y"] -= ny * overlap * 0.5
                    other["x"] += nx * overlap * 0.5
                    other["y"] += ny * overlap * 0.5
                    # 反発
                    pe["vx"] -= nx * 50 * dt
                    pe["vy"] -= ny * 50 * dt
                    other["vx"] += nx * 50 * dt
                    other["vy"] += ny * 50 * dt

def draw_gummy_char(screen, gx, gy, gz, color, size=1.0, etype="PLAYER", fdx=1, fdy=0, anim_timer=0, is_damaged=False, extra_squish=1.0, rotation=0, is_angular=False, alpha=255):
    """自機・敵・ボスを3Dグミとして描画する"""
    # 1. 描画ターゲットの準備 (半透明対応)
    if alpha < 255:
        tw, th = 200, 200
        target = pygame.Surface((tw, th), pygame.SRCALPHA)
        bx, by = to_iso(gx, gy, gz)
        def local_to_iso(rgx, rgy, rgz):
            px, py = to_iso(rgx, rgy, rgz)
            return (px - bx + tw//2, py - by + th*0.7)
    else:
        target = screen
        local_to_iso = to_iso

    # 2. 基本形状のパラメータ計算
    num_slices = 6
    w_h = 28 * size * extra_squish
    widening = 1.0 + max(0, 1.0 - extra_squish) * 1.5
    h_scale_base = size * widening
    eps_r = 0.05 if is_angular else 0.3
    squish = math.sin(anim_timer * 15.0) * 0.05
    
    # 3. 各層（スライス）の頂点計算
    all_slice_pts = []
    for s_idx in range(num_slices):
        h_pct = s_idx / (num_slices - 1)
        s_scale = (0.85 + math.sin(h_pct * math.pi) * 0.15 + squish) * h_scale_base
        z_off = w_h * h_pct
        s_pts = []
        for i, (rcx, rcy, start_a) in enumerate([(eps_r, eps_r, math.pi), (1-eps_r, eps_r, 1.5*math.pi), (1-eps_r, 1-eps_r, 0), (eps_r, 1-eps_r, 0.5*math.pi)]):
            for j in range(4):
                angle = start_a + (j / 3) * (math.pi / 2)
                rx = (rcx + math.cos(angle) * eps_r - 0.5) * s_scale
                ry = (rcy + math.sin(angle) * eps_r - 0.5) * s_scale
                if rotation != 0:
                    cos_a, sin_a = math.cos(rotation), math.sin(rotation)
                    rx, ry = rx * cos_a - ry * sin_a, rx * sin_a + ry * cos_a
                s_pts.append(local_to_iso(gx + size/2.0 + rx, gy + size/2.0 + ry, gz + z_off))
        all_slice_pts.append(s_pts)

    # 4. ポリゴンの描画
    for s_idx in range(num_slices - 1):
        pts_low, pts_high = all_slice_pts[s_idx], all_slice_pts[s_idx+1]
        h_pct = s_idx / (num_slices - 1)
        for p_idx in range(len(pts_low)):
            next_p = (p_idx + 1) % len(pts_low)
            br = 0.6 + 0.3 * h_pct
            if 4 <= p_idx < 12: br += 0.1
            s_color = (int(color[0]*br), int(color[1]*br), int(color[2]*br))
            pygame.draw.polygon(target, s_color, [pts_low[p_idx], pts_low[next_p], pts_high[next_p], pts_high[p_idx]])
    pygame.draw.polygon(target, color, all_slice_pts[-1])

    # 5. 顔（目）の描画
    # ボスは巨大な時は顔を描画しないが、1x1サイズ(size=1.0)になった時だけ目を出す
    if etype != "BOSS" or size <= 1.2:
        face_off = 0.2 * size + 0.15 if size > 1.5 else 0.3 * size
        fx, fy = gx + size / 2.0 + fdx * face_off, gy + size / 2.0 + fdy * face_off
        
        if fdx > 0 or fdy > 0:
            eye_sep = 0.15 * 1.5 + (size - 1.5) * 0.05 if size > 1.5 else 0.15 * size
            if fdx > 0 and fdy > 0:
                ex1 = local_to_iso(fx - eye_sep, fy + eye_sep, gz + w_h * 0.75)
                ex2 = local_to_iso(fx + eye_sep, fy - eye_sep, gz + w_h * 0.75)
            elif fdx > 0:
                ex1 = local_to_iso(fx, fy - eye_sep, gz + w_h * 0.75)
                ex2 = local_to_iso(fx, fy + eye_sep, gz + w_h * 0.75)
            else:
                ex1 = local_to_iso(fx - eye_sep, fy, gz + w_h * 0.75)
                ex2 = local_to_iso(fx + eye_sep, fy, gz + w_h * 0.75)
            
            if is_damaged:
                s = 4 * size
                if fdx > 0:
                    # 右向き時は (<>)
                    pygame.draw.line(target, (0,0,0), (int(ex1[0]+s), int(ex1[1]-s)), (int(ex1[0]), int(ex1[1])), 2)
                    pygame.draw.line(target, (0,0,0), (int(ex1[0]+s), int(ex1[1]+s)), (int(ex1[0]), int(ex1[1])), 2)
                    pygame.draw.line(target, (0,0,0), (int(ex2[0]-s), int(ex2[1]-s)), (int(ex2[0]), int(ex2[1])), 2)
                    pygame.draw.line(target, (0,0,0), (int(ex2[0]-s), int(ex2[1]+s)), (int(ex2[0]), int(ex2[1])), 2)
                else:
                    # それ以外（下向きなど）は従来の (><)
                    pygame.draw.line(target, (0,0,0), (int(ex1[0]-s), int(ex1[1]-s)), (int(ex1[0]), int(ex1[1])), 2)
                    pygame.draw.line(target, (0,0,0), (int(ex1[0]-s), int(ex1[1]+s)), (int(ex1[0]), int(ex1[1])), 2)
                    pygame.draw.line(target, (0,0,0), (int(ex2[0]+s), int(ex2[1]-s)), (int(ex2[0]), int(ex2[1])), 2)
                    pygame.draw.line(target, (0,0,0), (int(ex2[0]+s), int(ex2[1]+s)), (int(ex2[0]), int(ex2[1])), 2)
            else:
                pygame.draw.circle(target, (0,0,0), (int(ex1[0]), int(ex1[1])), max(1, int(3 * size)))
                pygame.draw.circle(target, (0,0,0), (int(ex2[0]), int(ex2[1])), max(1, int(3 * size)))

    # 6. アニマルパーツ（耳・角・鼻）の描画
    cx, cy = gx + size / 2.0, gy + size / 2.0
    sub_color = (int(color[0]*0.85), int(color[1]*0.85), int(color[2]*0.85))
    mag = math.sqrt(fdx*fdx + fdy*fdy) or 1
    ux, uy = fdx / mag, fdy / mag # 正面ベクトル
    sx, sy = uy, -ux # 側面ベクトル

    if etype == "E1": # 犬 (Dog)
        for side in [-1, 1]:
            ex, ey = ux*-0.1*size + sx*side*0.35*size, uy*-0.1*size + sy*side*0.35*size
            e_base = local_to_iso(cx + ex, cy + ey, gz + w_h)
            e_mid = local_to_iso(cx + ex*1.4, cy + ey*1.4, gz + w_h * 0.7)
            pygame.draw.line(target, sub_color, e_base, e_mid, int(8*size))
            pygame.draw.circle(target, sub_color, (int(e_mid[0]), int(e_mid[1])), int(5*size))
    elif etype == "E2": # 猫 (Cat)
        for side in [-1, 1]:
            ex, ey = sx*side*0.25*size, sy*side*0.25*size
            e_top = local_to_iso(cx + ex, cy + ey, gz + w_h + 10*size)
            b1 = local_to_iso(cx + ex + ux*0.15*size, cy + ey + uy*0.15*size, gz + w_h - 2*size)
            b2 = local_to_iso(cx + ex - ux*0.15*size, cy + ey - uy*0.15*size, gz + w_h - 2*size)
            pygame.draw.polygon(target, (min(255, int(color[0]*1.2)), min(255, int(color[1]*1.2)), min(255, int(color[2]*1.2))), [e_top, b1, b2])
    elif etype == "E3": # ウサギ (Rabbit)
        for side in [-1, 1]:
            ex, ey = ux*-0.1*size + sx*side*0.15*size, uy*-0.1*size + sy*side*0.15*size
            e_top = local_to_iso(cx + ex, cy + ey, gz + w_h + 26*size)
            e_base = local_to_iso(cx + ex, cy + ey, gz + w_h - 2*size)
            pygame.draw.line(target, sub_color, e_base, e_top, int(8*size))
            pygame.draw.circle(target, sub_color, (int(e_top[0]), int(e_top[1])), int(4*size))
            pygame.draw.circle(target, (255, 200, 220), (int(e_top[0]), int(e_top[1])), int(2*size))
    elif etype == "E4": # ウシ (Cow)
        for side in [-1, 1]:
            ex, ey = sx*side*0.25*size, sy*side*0.25*size
            h_top = local_to_iso(cx + ex + ux*0.1*size, cy + ey + uy*0.1*size, gz + w_h + 10*size)
            h_base = local_to_iso(cx + ex, cy + ey, gz + w_h)
            pygame.draw.line(target, (240, 240, 200), h_base, h_top, int(5*size))
            e_mid = local_to_iso(cx + ex*1.8, cy + ey*1.8, gz + w_h - 4*size)
            pygame.draw.line(target, sub_color, h_base, e_mid, int(6*size))

    # 7. 画面への合成
    if alpha < 255:
        target.set_alpha(alpha)
        screen.blit(target, (bx - tw//2, by - th*0.7))

def draw_gummy_char_ui(screen, x, y, color, size=1.0, etype="PLAYER", anim_timer=0):
    """UI上の指定したスクリーン座標(x, y)にグミキャラクターを描画する"""
    # to_iso(0,0,0) が (x, y) になるように一時的にオフセットを調整する
    global ISO_OFFSET_X, ISO_OFFSET_Y
    old_ox, old_oy = ISO_OFFSET_X, ISO_OFFSET_Y
    ISO_OFFSET_X, ISO_OFFSET_Y = x, y
    draw_gummy_char(screen, 0, 0, 0, color, size, etype, 1, 0, anim_timer)
    ISO_OFFSET_X, ISO_OFFSET_Y = old_ox, old_oy

def draw_foundation(screen, x, y, z_base, thickness, base_color, is_simple=False):
    """タイルの下に重なる「土台（ガワ）」を描画する"""
    # 土台は床のグミとは別オブジェクト感を出すため、少し暗めでマットな色にする
    shadow_color = (int(base_color[0]*0.5), int(base_color[1]*0.5), int(base_color[2]*0.5))
    side_color = (int(base_color[0]*0.95), int(base_color[1]*0.95), int(base_color[2]*0.95))

    # 頂点計算用の関数（事前計算されたテーブルを使用: Idea 4）
    def get_rounded_pts(z_off, scale=1.0):
        pts = []
        if is_simple:
            # シンプル版: 4角のみ
            pts.append(to_iso(x + 0.05, y + 0.05, z_off))
            pts.append(to_iso(x + 0.95, y + 0.05, z_off))
            pts.append(to_iso(x + 0.95, y + 0.95, z_off))
            pts.append(to_iso(x + 0.05, y + 0.95, z_off))
        else:
            # テーブルから相対座標を取得し、現在の位置と高さに変換
            # scale が 1.0 でない場合（foundationの絞り込みなど）は中心基準でスケール
            for dx, dy in ISO_VERTEX_TABLE:
                if scale != 1.0:
                    dx = 0.5 + (dx - 0.5) * scale
                    dy = 0.5 + (dy - 0.5) * scale
                pts.append(to_iso(x + dx, y + dy, z_off))
        return pts

    # 25pxずつの「段」を、さらに2層に分けて描画して丸みを出す (Idea 3 & 4 適用)
    num_segments = thickness // 25
    for s in range(num_segments):
        for sub in range(2): # 1段を2つのパーツで構成して丸みを表現
            sub_pct = sub / 2
            next_sub_pct = (sub + 1) / 2
            
            s_z_top = z_base - (s * 25) - (sub_pct * 25)
            s_z_bottom = z_base - (s * 25) - (next_sub_pct * 25)
            
            # グミのような丸みを出すためのスケール計算
            # sub_pct: 0.0 -> 0.5 -> 1.0 に対して 0.85 -> 1.0 -> 0.85 と変化させる
            s_scale = 0.85 + 0.15 * math.sin(sub_pct * math.pi)
            next_s_scale = 0.85 + 0.15 * math.sin(next_sub_pct * math.pi)
            
            pts_top = get_rounded_pts(s_z_top, scale=s_scale)
            pts_bottom = get_rounded_pts(s_z_bottom, scale=next_s_scale)
            
            # 側面を描画（背面カリング適用）
            num_pts = len(pts_top)
            for i in range(num_pts):
                if not is_simple:
                    if x == GRID_SIZE - 1 and y != GRID_SIZE - 1:
                        if not (4 <= i <= 11): continue
                    elif y == GRID_SIZE - 1 and x != GRID_SIZE - 1:
                        if not (i >= 8 or i <= 0): continue
                    elif x == GRID_SIZE - 1 and y == GRID_SIZE - 1:
                        if not (i >= 4 or i <= 0): continue

                next_i = (i + 1) % num_pts
                # 下の段ほど少しずつ暗く
                darken = 1.0 - (s * 0.05)
                br = (0.9 + 0.1 * math.sin(i / num_pts * math.pi * 2)) * darken
                c = (int(side_color[0]*br), int(side_color[1]*br), int(side_color[2]*br))
                pygame.draw.polygon(screen, c, [pts_top[i], pts_top[next_i], pts_bottom[next_i], pts_bottom[i]])
    
    # 底部は描画しない（見えないため）

def draw_tile(screen, x, y, z_base, flavor, animation_timer, tile_jiggles, override_color=None, is_simple=False):
    """ぷにぷにのグミタイルを描画する"""
    z = z_base
    if not is_simple:
        # 常時ぷるぷるさせる波 (壁と同様のロジックでランダム感を出す)
        t_wave = math.sin(animation_timer * 7.0 + x * 1.2 + y * 1.8)
        if t_wave > 0.94: # しきい値を上げて頻度を低く
            z += int((t_wave - 0.94) * 20) # 震える時は少し強めに

        # 揺れ演出の適用 (踏んだ時など)
        tz = 0
        if (x, y) in tile_jiggles:
            # 乗った瞬間に沈み込み、少し跳ねる (高さを強調)
            j_timer = tile_jiggles[(x, y)]
            tz = -int(math.sin(j_timer * 40) * (j_timer / 0.2) * 7)
        z += tz
    
    thickness = 30
    
    # 色の決定
    base_color = override_color if override_color else GRID_COLOR
    if flavor == "MINT": base_color = (180, 240, 255)
    elif flavor == "SODA": base_color = (150, 255, 200)
    elif flavor == "CARAMEL": base_color = (230, 160, 80)
    elif flavor == "POPPING": base_color = (255, 255, 100)
    elif flavor == "SHOP": base_color = (250, 245, 235)
    
    shadow_color = (int(base_color[0]*0.7), int(base_color[1]*0.7), int(base_color[2]*0.7))
    side_color = (int(base_color[0]*0.85), int(base_color[1]*0.85), int(base_color[2]*0.85))

    # 頂点計算（テーブル参照）
    def get_tile_pts_cached(z_off, scale=1.0):
        pts = []
        if is_simple:
            pts.append(to_iso(x + 0.05, y + 0.05, z_off))
            pts.append(to_iso(x + 0.95, y + 0.05, z_off))
            pts.append(to_iso(x + 0.95, y + 0.95, z_off))
            pts.append(to_iso(x + 0.05, y + 0.95, z_off))
        else:
            for dx, dy in ISO_VERTEX_TABLE:
                if scale != 1.0:
                    dx = 0.5 + (dx - 0.5) * scale
                    dy = 0.5 + (dy - 0.5) * scale
                pts.append(to_iso(x + dx, y + dy, z_off))
        return pts

    # 側面（シェル）の描画
    num_layers = 2 if is_simple else 4 # ぷっくり感を出すためにレイヤー数を戻す
    for l_idx in range(num_layers):
        l_pct = l_idx / num_layers
        next_pct = (l_idx + 1) / num_layers
        
        l_z = z - (thickness * (1.0 - l_pct))
        next_l_z = z - (thickness * (1.0 - next_pct))
        
        l_scale = 1.0 if is_simple else (0.85 + 0.15 * math.sin(l_pct * math.pi))
        next_l_scale = 1.0 if is_simple else (0.85 + 0.15 * math.sin(next_pct * math.pi))
        
        l_pts = get_tile_pts_cached(l_z, l_scale)
        next_l_pts = get_tile_pts_cached(next_l_z, next_l_scale)
        
        # 側面のみを描画（背面カリング適用: Idea 3）
        s_br = 0.6 + 0.3 * l_pct
        curr_side_color = (int(base_color[0]*s_br), int(base_color[1]*s_br), int(base_color[2]*s_br))
        for i in range(len(l_pts)):
            # プレイヤー視点で見える面（i=4〜16）のみを描画
            if not is_simple and not (i >= 4 or i <= 0): continue
            
            ni = (i + 1) % len(l_pts)
            pygame.draw.polygon(screen, curr_side_color, [l_pts[i], l_pts[ni], next_l_pts[ni], next_l_pts[i]])

    # 最上面のみを描画 (少し小さく絞る)
    top_pts = get_tile_pts_cached(z, 0.9)
    pygame.draw.polygon(screen, base_color, top_pts)

    # フレーバー演出は高品質時のみ
    if is_simple: return

    # フレーバーごとの追加演出 (最上層の座標を使用)
    top_pts = get_tile_pts_cached(z, 0.9) # 最上層は少し絞られているので合わせる
    if flavor == "MINT":
        # ミントの葉っぱ風
        p1 = to_iso(x+0.3, y+0.3, z+1)
        p2 = to_iso(x+0.7, y+0.7, z+1)
        pygame.draw.line(screen, WHITE, p1, p2, 2)
    elif flavor == "SODA":
        for i in range(3):
            bubble_y = top_pts[0][1] + 10 - ((animation_timer * 20 + i * 10) % 20)
            bubble_x = top_pts[0][0] + 15 + (i * 8) + math.sin(animation_timer * 5 + i) * 3
            pygame.draw.circle(screen, WHITE, (int(bubble_x), int(bubble_y)), 3, 1)
    elif flavor == "CARAMEL":
        # ぷくぷく泡 (量を増やして6つ)
        for i in range(6):
            ox = [0.2, 0.7, 0.4, 0.8, 0.3, 0.6][i]
            oy = [0.3, 0.4, 0.7, 0.2, 0.8, 0.6][i]
            phase = i * 1.3
            life = (animation_timer + phase) % 4.0
            if life < 1.2:
                b_size = math.sin((life/1.2) * math.pi) * 7
                bp = to_iso(x + ox, y + oy, z + 2)
                pygame.draw.circle(screen, (160, 90, 40), bp, int(b_size))
                if b_size > 2:
                    hp = (bp[0] - b_size*0.3, bp[1] - b_size*0.3)
                    pygame.draw.circle(screen, (240, 180, 100), hp, int(b_size*0.2))
    elif flavor == "POPPING":
        # パチパチ火花 (大きく、広く、量を増やして10個)
        for i in range(10):
            seed_val = (animation_timer * 15 + i * 8.3 + x * 13 + y * 31) % 12.0
            if seed_val < 1.2:
                prog = seed_val / 1.2
                # 範囲を広げる (-0.1 ~ 1.1 くらいまで許容してタイルの外側にも少しはみ出す)
                rx = (math.sin(i * 1.7 + x + y) * 0.6 + 0.5)
                ry = (math.cos(i * 2.5 + x - y) * 0.6 + 0.5)
                sp = to_iso(x + rx, y + ry, z + 3) # 少し高めに表示
                s_color = WHITE if i % 3 == 0 else (255, 180, 0) # 黄色を濃くして白を見えやすく
                s_size = 3 if prog < 0.5 else 1 # 少し大きく
                pygame.draw.circle(screen, s_color, sp, s_size)
                if prog < 0.5:
                    # 火花の線を長く
                    pygame.draw.line(screen, s_color, (sp[0]-6, sp[1]), (sp[0]+6, sp[1]), 1)
                    pygame.draw.line(screen, s_color, (sp[0], sp[1]-6), (sp[0], sp[1]+6), 1)

def draw_wall(screen, x, y, z_base, animation_timer, wall_jiggles, is_simple=False):
    """マシュマロ風の壁を描画する"""
    w_h = 30
    if not is_simple:
        w_wave = math.sin(animation_timer * 8.0 + x * 2 + y * 3)
        if w_wave > 0.8: w_h += int((w_wave - 0.8) * 20)
        if (x, y) in wall_jiggles:
            j_timer, j_dx, j_dy = wall_jiggles[(x, y)]
            w_h += int(math.sin((0.3 - j_timer) * 40) * (j_timer/0.3) * 15)

    num_slices = 2 if is_simple else 6
    eps_r = 0.3
    for s_idx in range(num_slices):
        h_pct = s_idx / (num_slices - 1)
        s_scale = 1.0 if is_simple else (0.85 + math.sin(h_pct * math.pi) * 0.15)
        z_off = w_h * h_pct
        br = 0.6 + 0.4 * h_pct
        s_color = (int(WALL_COLOR[0]*br), int(WALL_COLOR[1]*br), int(WALL_COLOR[2]*br))
        
        s_pts = []
        for i, (cx, cy, start_a) in enumerate([
            (eps_r, eps_r, math.pi), (1-eps_r, eps_r, 1.5*math.pi),
            (1-eps_r, 1-eps_r, 0), (eps_r, 1-eps_r, 0.5*math.pi)
        ]):
            for j in range(4):
                angle = start_a + (j / 3) * (math.pi / 2)
                px = x + 0.5 + (cx + math.cos(angle) * eps_r - 0.5) * s_scale
                py = y + 0.5 + (cy + math.sin(angle) * eps_r - 0.5) * s_scale
                s_pts.append(to_iso(px, py, z_base + z_off))
        
        pygame.draw.polygon(screen, s_color, s_pts)

def draw_exit(screen, x, y, z_base, animation_timer):
    """出口ゲートを描画する"""
    ex_h = 10 + int(math.sin(animation_timer * 8.0) * 5)
    r = 0.4 # 角の丸みをタイルに合わせる
    size = 0.9 # タイルに合わせる
    
    def get_rounded_pts(cx, cy, cz):
        pts = []
        corners = [(r, r, math.pi), (1-r, r, 1.5*math.pi), (1-r, 1-r, 0), (r, 1-r, 0.5*math.pi)]
        for crx, cry, start_a in corners:
            num_seg = 5 # 分割数を増やして滑らかに
            for j in range(num_seg):
                angle = start_a + (j / (num_seg - 1)) * (math.pi / 2)
                px = cx + 0.5 + (crx + math.cos(angle) * r - 0.5) * size
                py = cy + 0.5 + (cry + math.sin(angle) * r - 0.5) * size
                pts.append(to_iso(px, py, cz))
        return pts

    pts_low = get_rounded_pts(x, y, z_base)
    pts_high = get_rounded_pts(x, y, z_base + ex_h)

    # 側面
    for i in range(len(pts_low)):
        ni = (i + 1) % len(pts_low)
        br = 0.8 if i >= 6 else 0.6
        c = (int(EXIT_COLOR[0]*br), int(EXIT_COLOR[1]*br), int(EXIT_COLOR[2]*br))
        pygame.draw.polygon(screen, c, [pts_low[i], pts_low[ni], pts_high[ni], pts_high[i]])
        
    # 上面
    pygame.draw.polygon(screen, EXIT_COLOR, pts_high)
    
    # 矢印 (元の大きさに戻す)
    ax, ay = to_iso(x + 0.5, y + 0.5, z_base + ex_h)
    pygame.draw.polygon(screen, WHITE, [(ax, ay-12), (ax-8, ay), (ax+8, ay)])
    pygame.draw.rect(screen, WHITE, (ax-3, ay, 6, 10))


def draw_enemy_face(surface, etype, rect_x, rect_y):
    pass # 3D化により未使用

GUMMY_FONT = {
    'G': ["111", "100", "101", "101", "111"],
    'U': ["101", "101", "101", "101", "111"],
    'M': ["10001", "11011", "10101", "10001", "10001"],
    'I': ["010", "010", "010", "010", "010"],
    '-': ["000", "000", "111", "000", "000"],
    'T': ["111", "010", "010", "010", "010"],
    'O': ["111", "101", "101", "101", "111"],
    'W': ["10101", "10101", "10101", "11011", "01010"],
    'A': ["010", "101", "111", "101", "101"],
}

def draw_gummy_text(surface, text, x, y, size, color, total_time):
    curr_x = x
    for i, char in enumerate(text):
        if char not in GUMMY_FONT:
            curr_x += size * 3
            continue
        pattern = GUMMY_FONT[char]
        width = len(pattern[0])
        for row in range(5):
            for col in range(width):
                if pattern[row][col] == '1':
                    # 各粒ごとに大きく位相をずらしてダイナミックにランダムにぷるぷよさせる
                    phase = ((col * 83 + row * 113 + i * 257) % 628) / 100.0
                    wave = math.sin(total_time * 15.0 + phase)
                    sq_x, sq_y = 0, 0
                    if wave > 0.3:
                        sq_x = int((wave-0.3)*4)
                        sq_y = int((wave-0.3)*-2)
                    r = (curr_x + col*(size+1) - sq_x//2, y + row*(size+1) - sq_y, size + sq_x, size + sq_y)
                    pygame.draw.rect(surface, color, r, border_radius=max(1, size//3))
        curr_x += (width * (size + 1)) + size

def draw_text(surface, text, x, y, color=BLACK, font_obj=font):
    img = font_obj.render(text, True, color)
    surface.blit(img, (x, y))

def draw_skill_icon(surface, x, y, size, name, color=BLACK):
    """スキルのアイコンを描画する"""
    if not name:
        # 空のスロット
        pygame.draw.rect(surface, color, (x, y, size, size), width=1, border_radius=4)
        return

    # アイコンの背景
    rect = (x, y, size, size)
    pygame.draw.rect(surface, WHITE, rect, border_radius=4)
    pygame.draw.rect(surface, color, rect, width=1, border_radius=4)

    cx, cy = x + size // 2, y + size // 2
    s = size // 4

    if name == "回復":
        # ハート型
        pygame.draw.circle(surface, (255, 120, 150), (cx - s, cy - s), s)
        pygame.draw.circle(surface, (255, 120, 150), (cx + s, cy - s), s)
        pygame.draw.polygon(surface, (255, 120, 150), [(cx - s*2, cy - s), (cx + s*2, cy - s), (cx, cy + s*2)])
    elif name == "貫通":
        # ドリル
        pygame.draw.polygon(surface, (255, 200, 50), [(cx, cy - s*1.5), (cx + s*1.5, cy + s*1.5), (cx - s*1.5, cy + s*1.5)])
        pygame.draw.line(surface, color, (cx - s, cy), (cx + s, cy), 1)
        pygame.draw.line(surface, color, (cx - s, cy + s), (cx + s, cy + s), 1)
    elif name == "回転":
        # 回転 (3本の弧で回転感を演出 - 静止画)
        for i in range(3):
            start_a = i * (math.pi * 2 / 3) + 0.5
            rect_arc = (x+4, y+4, size-8, size-8)
            pygame.draw.arc(surface, (50, 180, 255), rect_arc, start_a, start_a + 2.0, 3)
        pygame.draw.circle(surface, (50, 180, 255), (cx, cy), 2)
    elif name == "投擲":
        # 小石と軌跡 (三本線でスピード感を演出)
        for i in range(3):
            ly = cy - 4 + i * 4
            pygame.draw.line(surface, (150, 150, 150), (x+4, ly), (cx-2, ly), 2)
        pygame.draw.circle(surface, (100, 100, 100), (cx+4, cy), s)
    elif name == "停止":
        # 時計の文字盤
        pygame.draw.circle(surface, (180, 100, 255), (cx, cy), s * 1.8, width=2)
        pygame.draw.line(surface, BLACK, (cx, cy), (cx, cy - s), 2)
        pygame.draw.line(surface, BLACK, (cx, cy), (cx + s//2, cy), 2)
    elif name == "跳躍":
        # 何かを飛び越える演出 (障害物と放物線矢印)
        # 1. 障害物
        pygame.draw.rect(surface, (120, 120, 120), (cx - 3, cy + s - 2, 6, 6), border_radius=1)
        # 2. 放物線 (位置を少し下げる)
        rect_jump = (x+4, y+size//4 + 4, size-8, size//2)
        pygame.draw.arc(surface, (100, 220, 100), rect_jump, 0.2, 2.9, 2)
        # 3. 矢先 (位置微調整: 少し上へ)
        pygame.draw.polygon(surface, (100, 220, 100), [
            (x + size - 4, cy + s - 5), (x + size - 10, cy + s - 9), (x + size - 10, cy + s - 1)
        ])
    elif name == "重撃":
        # 分銅
        pygame.draw.circle(surface, (50, 80, 200), (cx, y+6), 4, width=2)
        pygame.draw.polygon(surface, (50, 80, 200), [(cx-s*1.5, cy+s*1.5), (cx+s*1.5, cy+s*1.5), (cx+s, cy-s), (cx-s, cy-s)])
    elif name == "自爆":
        # 爆発マーク
        points = []
        for i in range(12):
            angle = math.radians(i * 30)
            r = size//2 - 2 if i % 2 == 0 else size//3
            points.append((cx + math.cos(angle)*r, cy + math.sin(angle)*r))
        pygame.draw.polygon(surface, (255, 80, 0), points)

def draw_item_icon(surface, x, y, size, item_type):
    """J(ジュース)やG(ゼラチン)のアイコンを描画する"""
    cx, cy = x + size // 2, y + size // 2
    if item_type == "J":
        # ジュースボトル
        pygame.draw.rect(surface, (230, 150, 255), (cx-size//4, cy-size//4, size//2, size//1.5), border_radius=3)
        pygame.draw.rect(surface, (255, 200, 255), (cx-size//4+2, cy-size//4+2, size//2-4, size//3), border_radius=2)
        pygame.draw.line(surface, BLACK, (cx, cy-size//4), (cx+size//4, cy-size//2), 2) # ストロー
    else:
        # ゼラチン（粉末袋）
        pygame.draw.polygon(surface, (255, 220, 100), [(cx-size//3, cy+size//3), (cx+size//3, cy+size//3), (cx+size//4, cy-size//3), (cx-size//4, cy-size//3)])
        pygame.draw.line(surface, (200, 150, 50), (cx-size//4, cy), (cx+size//4, cy), 1) # 袋の模様


def collect_floor_tasks(screen, game, f_data, fz, animation_timer, render_tasks, is_current=True, is_simple=False, only_floor=False):
    """特定の階層（現在の階層または保存された古い階層）の描画タスクを収集する"""
    j_y = int(math.sin(animation_timer * 15) * 2)
    # 遷移演出中の高さ計算 (共通オフセット: 新しい階層のみ適用)
    trans_fz_off = 0
    if is_current and game.transition_timer > 0:
        prog = 1.0 - game.transition_timer
        trans_fz_off = (1.0 - prog) * 800
    
    if f_data == "TOWER_BASE":
        for y in range(GRID_SIZE):
            for x in range(GRID_SIZE):
                render_tasks.append({
                    "depth": x * 12 + y * 30 - 500 + fz, # 十分奥に
                    "func": draw_tile,
                    "args": (screen, x, y, fz, None, animation_timer, {}, None, True) # TOWER_BASEは常にシンプル
                })
        return

    if is_current:
        walls = game.walls
        flavor_tiles = game.flavor_tiles
        enemies = game.enemies
        items = game.items
        exit_pos = game.exit_pos
        is_shop = (game.state == "SHOP")
    else:
        walls = f_data["walls"]
        flavor_tiles = f_data["flavor"]
        enemies = f_data["enemies"]
        items = f_data["items"]
        exit_pos = f_data.get("exit_pos")
        is_shop = f_data.get("is_shop", False)

    # 1. 床・壁・出口
    for y in range(GRID_SIZE):
        for x in range(GRID_SIZE):
            # 遷移演出中の高さ計算 (個別オフセット)
            fz_off = trans_fz_off
            if is_current and game.transition_timer > 0:
                prog = 1.0 - game.transition_timer
                if x == game.player_x and y == game.player_y:
                    # 自機がいるマスは少し浮き上がってから着地 (高さを強調)
                    fz_off = trans_fz_off + math.sin(prog * math.pi) * 65

            if is_current and not is_simple:
                # タイルの揺れ判定
                if (game.player_x == x and game.player_y == y):
                    game.tile_jiggles[(x, y)] = 0.2
                else:
                    for e in enemies:
                        if e["x"] == x and e["y"] == y:
                            game.tile_jiggles[(x, y)] = 0.2
                            break
                if game.boss_active and game.is_boss_hit(x, y):
                    game.tile_jiggles[(x, y)] = 0.2

            # タイルの色（ロビーなどの特殊タイル対応）
            tile_override_color = None
            if is_current and game.floor == 0 and game.state in ("LOBBY", "LOBBY_MENU", "LOBBY_LIMIT_MENU", "COUNTDOWN"):
                if (x, y) == game.lobby_start_pos: tile_override_color = (130, 255, 130)
                elif (x, y) == game.lang_tile_pos: tile_override_color = (180, 180, 200) # 言語切替マス
                # if game.itemless_unlocked and (x, y) == game.itemless_start_pos:
                #     tile_override_color = (255, 100, 100) # 限定モードは赤っぽいタイル
                elif (x, y) == game.time_attack_start_pos: tile_override_color = (255, 150, 100)
                elif (x, y) == game.time_limit_start_pos: tile_override_color = (100, 200, 255)
                elif (x, y) == (3, 7): tile_override_color = (255, 255, 150) # ヘルプマス
                elif (x, y) == (5, 7): tile_override_color = (230, 200, 255) # スキル解説マス
                elif (x, y) == (7, 7): tile_override_color = (180, 220, 255) # キャラクター一覧マス
                elif (x, y) == (1, 7): tile_override_color = (200, 255, 200) # ストーリーマス

            flavor = flavor_tiles.get((x, y))
            
            # 階層に応じた厚み（1cm〜10cm）の計算
            # ユーザーの要望: 落下中は1cm（積み重なっていない状態）、着地した瞬間に段数を増やす
            if is_current and game.transition_timer > 0:
                display_cm = 1
            else:
                display_cm = min(10, (game.floor if is_current else f_data.get("floor", 1)))
            
            num_foundation_steps = max(0, display_cm - 1)
            
            # グリッドの端（x=8 または y=8）だけ土台を描画することで、島全体の厚みを表現する
            is_edge = (x == GRID_SIZE - 1 or y == GRID_SIZE - 1)
            if num_foundation_steps > 0 and is_edge:
                f_thickness = num_foundation_steps * 25 # 合計の厚み
                # 土台の色: ユーザーの要望により白・灰色系にする
                f_base_color = (210, 210, 210)
                if tile_override_color:
                    # 特殊タイルの場合は少しその色を混ぜる (20% color + 80% gray)
                    f_base_color = (
                        int(tile_override_color[0] * 0.2 + 210 * 0.8),
                        int(tile_override_color[1] * 0.2 + 210 * 0.8),
                        int(tile_override_color[2] * 0.2 + 210 * 0.8)
                    )
                
                # 土台はアニメーションさせず静的に配置。形状は角丸を維持するため is_simple を反映。
                render_tasks.append({
                    "depth": x * 12 + y * 30 - 20 + fz,
                    "func": draw_foundation,
                    "args": (screen, x, y, fz - 30, f_thickness, f_base_color, is_simple)
                })

            render_tasks.append({
                "depth": x * 12 + y * 30 - 10 + fz + fz_off,
                "func": draw_tile,
                "args": (screen, x, y, fz + fz_off, flavor, animation_timer, game.tile_jiggles if is_current else {}, tile_override_color, is_simple)
            })
            
            if only_floor:
                continue

            if (x, y) in walls:
                render_tasks.append({
                    "depth": x * 12 + y * 30 + fz + fz_off,
                    "func": draw_wall,
                    "args": (screen, x, y, fz + fz_off, animation_timer, game.wall_jiggles if is_current else {}, is_simple)
                })
            
            if not is_shop and exit_pos == (x, y):
                render_tasks.append({
                    "depth": x * 12 + y * 30 + 5 + fz + fz_off,
                    "func": draw_exit,
                    "args": (screen, x, y, fz + fz_off, animation_timer)
                })

            # ショップ固有の要素 (出口、店員、商品)
            if is_shop:
                s_exit = game.shop_exit_pos if is_current else f_data.get("shop_exit")
                if s_exit == (x, y):
                    render_tasks.append({
                        "depth": x * 12 + y * 30 + 5 + fz + fz_off,
                        "func": draw_exit,
                        "args": (screen, x, y, fz + fz_off, animation_timer)
                    })

                s_item_pos = game.shop_item_pos if is_current else f_data.get("shop_items", [])
                s_offers = game.shop_offers if is_current else f_data.get("shop_offers", [])
                for i, pos in enumerate(s_item_pos):
                    if pos == (x, y) and i < len(s_offers):
                        offer = s_offers[i]
                        def draw_shop_item_task(scr, px, py, pz, p_offer, p_idx, game_ref):
                            is_purchasing = (game_ref.purchase_anim_timer > 0 and game_ref.purchased_item_idx == p_idx)
                            if is_purchasing:
                                # 購入演出中: フェードアウトとフラッシュ
                                prog = 1.0 - (game_ref.purchase_anim_timer / 0.5)
                                alpha = int((1.0 - prog) * 255)
                                flash = int(math.sin(prog * math.pi * 4) * 50) # 点滅
                                base_color = (255, 200, 100) if p_offer["type"] == "SKILL" else (100, 255, 100)
                                color = (min(255, base_color[0]+flash+100), min(255, base_color[1]+flash+100), min(255, base_color[2]+flash+100))
                            else:
                                if game_ref.purchase_anim_timer > 0: return # 他のアイテムは消す
                                wave = math.sin(animation_timer * 10.0 + p_idx * 2)
                                sq = int(wave * 3)
                                alpha = 255
                                color = (255, 200, 100) if p_offer["type"] == "SKILL" else (100, 255, 100)

                            ipx, ipy = to_iso(px + 0.5, py + 0.5, pz + 10 + (sq if not is_purchasing else 0))
                            
                            s = pygame.Surface((40, 40), pygame.SRCALPHA)
                            pygame.draw.circle(s, (*color, alpha), (20, 20), 18)
                            scr.blit(s, (int(ipx - 20), int(ipy - 20)))
                            
                            if p_offer["type"] == "SKILL":
                                # スキルアイコンも透明度を考慮して描画
                                icon_surf = pygame.Surface((30, 30), pygame.SRCALPHA)
                                draw_skill_icon(icon_surf, 0, 0, 30, p_offer["name"], color=BLACK)
                                icon_surf.set_alpha(alpha)
                                scr.blit(icon_surf, (int(ipx - 15), int(ipy - 15)))
                            else:
                                icon_surf = pygame.Surface((20, 20), pygame.SRCALPHA)
                                draw_item_icon(icon_surf, 0, 0, 20, p_offer["name"])
                                icon_surf.set_alpha(alpha)
                                scr.blit(icon_surf, (int(ipx - 10), int(ipy - 10)))
                        
                        render_tasks.append({
                            "depth": x * 12 + y * 30 + 15 + fz + fz_off,
                            "func": draw_shop_item_task,
                            "args": (screen, x, y, fz + fz_off, offer, i, game)
                        })


    if only_floor:
        return

    # 2. アイテム
    for i in items:
        def draw_item_at_grid(screen, ix, iy, iz, itype):
            px, py = to_iso(ix + 0.5, iy + 0.5, iz)
            draw_item_icon(screen, int(px - 10), int(py - 10), 20, itype)
        
        render_tasks.append({
            "depth": i["x"] * 12 + i["y"] * 30 + 5 + fz + trans_fz_off,
            "func": draw_item_at_grid,
            "args": (screen, i["x"], i["y"], fz + j_y + trans_fz_off, i["type"])
        })

    # 3. 敵
    for e in enemies:
        ex_offset, ey_offset, jump_y = 0, 0, 0
        prog = 0
        if is_current:
            if e.get("atk_timer", 0) > 0:
                prog = 1.0 - (e["atk_timer"] / 0.15)
                factor = (prog * 2) if prog < 0.5 else ((1.0 - prog) * 2)
                ex_offset, ey_offset = e.get("atk_dx", 0) * 0.5 * factor, e.get("atk_dy", 0) * 0.5 * factor
            elif e.get("move_timer", 0) > 0:
                prog = 1.0 - (e["move_timer"] / 0.075)
                ex_offset, ey_offset = e.get("move_dx", 0) * (1.0 - prog), e.get("move_dy", 0) * (1.0 - prog)
                jump_y = int(math.sin(prog * math.pi) * 15)
        
        h_off = 0
        if e["type"] == "E3":
            wall_h = 30
            h_start = wall_h if (e["x"] + e.get("move_dx", 0), e["y"] + e.get("move_dy", 0)) in walls else 0
            h_end = wall_h if (e["x"], e["y"]) in walls else 0
            if is_current and e.get("move_timer", 0) > 0:
                h_off = h_start * (1.0 - prog) + h_end * prog
            else: h_off = h_end

        c = ENEMY_COLORS.get(e["type"], ENEMY_COLORS["E1"])
        fdx, fdy = e.get("facing_dx", 1), e.get("facing_dy", 0)
        
        # 停止スキル適用中は敵の見た目の動きも止める (j_y と animation_timer を 0 に固定)
        e_j_y = j_y
        e_anim_timer = animation_timer
        if is_current and game.stop_buff > 0:
            e_j_y = 0
            e_anim_timer = 0

        render_tasks.append({
            "depth": (e["x"] + ex_offset) * 12 + (e["y"] + ey_offset) * 30 + 10 + fz + (e_j_y + jump_y + h_off) + trans_fz_off,
            "func": draw_gummy_char,
            "args": (screen, e["x"] + ex_offset, e["y"] + ey_offset, fz + e_j_y + jump_y + h_off + trans_fz_off, c, 0.8, e["type"], fdx, fdy, e_anim_timer)
        })

    # 4. ボス
    if is_current:
        # 通常時のボス
        if game.boss_active:
            s_cells = game.boss_size_cells
            sh_y = random.randint(-int(game.screen_shake), int(game.screen_shake)) if game.screen_shake > 0 else 0
            bcx, bcy = game.boss_x + s_cells/2.0, game.boss_y + s_cells/2.0
            render_tasks.append({
                "depth": bcx * 12 + bcy * 30 + 15 + fz + trans_fz_off,
                "func": draw_gummy_char,
                "args": (screen, game.boss_x, game.boss_y, fz + sh_y + trans_fz_off, (150, 50, 180), s_cells, "BOSS", game.boss_facing_dx, game.boss_facing_dy, animation_timer, getattr(game, "boss_damage_timer", 0) > 0)
            })
        # イントロ中のボス
        elif getattr(game, "boss_intro_state", None) in ("FALLING", "BLASTING"):
            bx, by = 3, 3 # spawn_bossで配置される位置
            s_cells = 3
            bz = 0
            if game.boss_intro_state == "FALLING":
                # 0.8秒かけて 800px から降りてくる
                prog = game.boss_intro_timer / 0.8 # 1.0 -> 0.0
                bz = prog * 800
            sh_y = random.randint(-int(game.screen_shake), int(game.screen_shake)) if game.screen_shake > 0 else 0
            bcx, bcy = bx + s_cells/2.0, by + s_cells/2.0
            render_tasks.append({
                "depth": bcx * 12 + bcy * 30 + 15 + fz + bz + trans_fz_off,
                "func": draw_gummy_char,
                "args": (screen, bx, by, fz + bz + sh_y + trans_fz_off, (150, 50, 180), s_cells, "BOSS", 1, 0, animation_timer, False)
            })

    # 5. プレイヤー
    # 遷移演出中 (transition_timer > 0) は、自機を「古い階層 (is_current=False)」に残す。
    # それ以外（着地後や通常時）は「現在の階層 (is_current=True)」に描画する。
    is_player_layer = False
    if game.transition_timer > 0:
        if not is_current and f_data != "TOWER_BASE":
            is_player_layer = True
    else:
        if is_current:
            is_player_layer = True

    if is_player_layer and game.state in ("PLAYING", "LOBBY", "COUNTDOWN", "BOSS", "SHOP", "BOSS_INTRO", "DYING", "WAITING_FOR_WIPE"):
        px_grid_off, py_grid_off, p_z = 0, 0, 0
        
        # 遷移演出中は、保存された古い座標を使用する
        if game.transition_timer > 0 and not is_current:
            cur_px = f_data.get("player_x", game.player_x)
            cur_py = f_data.get("player_y", game.player_y)
        else:
            cur_px = game.player_x
            cur_py = game.player_y

        if True: # アニメーション計算を常に有効化
            if game.state == "DYING":
                prog = (0.6 - game.dying_timer) / 0.6
                if game.death_cause == "DEAD":
                    # 吹き飛び演出 (ピクセル座標から逆算)
                    cur_px = (game.death_px - GRID_OFFSET_X) / CELL_SIZE
                    cur_py = (game.death_py - GRID_OFFSET_Y) / CELL_SIZE
                    p_z = int(math.sin(prog * math.pi) * 100)
                else:
                    # 落下演出: 最初は水平にさらに大きく外側へ押し出され、後から急激に落ちるように調整
                    px_grid_off = (game.death_x - game.player_x) * (prog ** 0.5) * 2.5
                    py_grid_off = (game.death_y - game.player_y) * (prog ** 0.5) * 2.5
                    p_z = -(prog ** 2) * 800
            elif game.heavy_atk_timer > 0:
                e_info, dist, dx, dy = game.heavy_atk_data
                prog = (0.6 - game.heavy_atk_timer) / 0.3 if game.heavy_atk_timer > 0.3 else game.heavy_atk_timer / 0.3
                px_grid_off, py_grid_off, p_z = dx * dist * prog, dy * dist * prog, int(math.sin(prog * math.pi) * 100)
            elif game.move_anim_timer > 0:
                max_t = getattr(game, "move_anim_max_timer", 0.075) or 0.075
                prog = 1.0 - (game.move_anim_timer / max_t)
                px_grid_off, py_grid_off = game.move_anim_dx * (1.0 - prog), game.move_anim_dy * (1.0 - prog)
                p_z = 0 if getattr(game, "is_sliding", False) else int(math.sin(prog * math.pi) * 20)
            elif game.pushback_anim_timer > 0:
                prog = 1.0 - (game.pushback_anim_timer / 0.15)
                px_grid_off, py_grid_off = game.pushback_anim_dx * (1.0 - prog), game.pushback_anim_dy * (1.0 - prog)
                p_z = int(math.sin(prog * math.pi) * 30)
            elif game.attack_anim_timer > 0:
                prog = 1.0 - (game.attack_anim_timer / 0.15)
                factor = (prog * 2) if prog < 0.5 else ((1.0 - prog) * 2)
                px_grid_off, py_grid_off = game.attack_anim_dx * 0.5 * factor, game.attack_anim_dy * 0.5 * factor

            # 敵に攻撃された時の視覚的な押し込み
            if getattr(game, "visual_push_timer", 0) > 0:
                v_prog = 1.0 - (game.visual_push_timer / 0.15)
                v_factor = (v_prog * 2) if v_prog < 0.5 else ((1.0 - v_prog) * 2)
                px_grid_off += game.visual_push_dx * 0.3 * v_factor
                py_grid_off += game.visual_push_dy * 0.3 * v_factor

        # 遷移演出中の浮き上がりをキャラにも適用
        if game.transition_timer > 0:
            p_prog = 1.0 - game.transition_timer
            p_z += int(math.sin(p_prog * math.pi) * 65)

        is_heavy = (game.heavy_atk_timer > 0)
        p_color = (130, 130, 140) if is_heavy else (210, 140, 70) if getattr(game, "caramel_stuck", False) else (255, 255, 0) if game.pierce_buff else (120, 255, 120) if game.jump_buff else PLAYER_COLOR
        p_size = 1.6 if is_heavy else 0.8
        
        # 回転攻撃演出
        p_extra_squish = 1.0
        p_rotation = 0
        if game.spin_anim_timer > 0:
            s_prog = 1.0 - (game.spin_anim_timer / 0.3)
            p_rotation = s_prog * math.pi * 6 # 3回転
            p_extra_squish = 1.0 - math.sin(s_prog * math.pi) * 0.5 # 最大0.5まで縮む
        
        j_y = random.randint(-int(game.screen_shake), int(game.screen_shake)) if game.screen_shake > 0 else 0
        render_tasks.append({
            "depth": (cur_px + px_grid_off) * 12 + (cur_py + py_grid_off) * 30 + 10 + fz + (j_y + p_z),
            "func": draw_gummy_char,
            "args": (screen, cur_px + px_grid_off, cur_py + py_grid_off, fz + j_y + p_z, p_color, p_size, "PLAYER", game.player_facing_dx, game.player_facing_dy, animation_timer, (game.damage_face_timer > 0 or game.state == "DYING"), p_extra_squish, p_rotation, is_heavy)
        })

        # ボス戦での遮蔽時シルエット演出
        if game.state == "BOSS" and game.boss_active and not is_heavy:
            # プレイヤーがボスの裏側にいるか判定
            # (ISO view では、グリッドのx, yがボスより小さいと奥側)
            if cur_px < game.boss_x + game.boss_size_cells and cur_py < game.boss_y + game.boss_size_cells:
                # 完全に重なっているか、わずかに奥ならシルエットを表示
                render_tasks.append({
                    "depth": 9999, # 最前面
                    "func": draw_gummy_char,
                    "args": (screen, cur_px + px_grid_off, cur_py + py_grid_off, fz + j_y + p_z, p_color, p_size, "PLAYER", game.player_facing_dx, game.player_facing_dy, animation_timer, (game.damage_face_timer > 0 or game.state == "DYING"), p_extra_squish, p_rotation, is_heavy, 100)
                })

    # 6. 投擲スキルの弾
    if game.throw_anim_timer > 0:
        prog = (0.2 - game.throw_anim_timer) / 0.2
        # プレイヤーのグリッド座標 + アニメーションオフセットを始点にする
        p_base_x = cur_px + px_grid_off
        p_base_y = cur_py + py_grid_off
        tx = p_base_x + game.throw_anim_dx * prog
        ty = p_base_y + game.throw_anim_dy * prog
        tz = fz + 10 + p_z # 自機の中心付近から飛ばす
        render_tasks.append({
            "depth": tx * 12 + ty * 30 + 15 + tz,
            "func": draw_gummy_char,
            "args": (screen, tx, ty, tz, p_color, 0.4, "PROJECTILE", 1, 0, animation_timer, False, 1.0, 0, False)
        })

def main():
    clock = pygame.time.Clock()
    game = GameState()
    
    GRID_OFFSET_X = 200 + (400 - GRID_SIZE*CELL_SIZE) // 2
    GRID_OFFSET_Y = (HEIGHT - GRID_SIZE*CELL_SIZE) // 2

    animation_timer = 0
    last_z_press_time = -1.0
    DOUBLE_TAP_THRESH = 0.3

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        animation_timer += dt
        
        game.update_time(dt)
        
        if getattr(game, "needs_reset", None):
            mode = game.needs_reset
            old_mode_attr = getattr(game, "mode", "ENDLESS")
            old_target_f = getattr(game, "target_floor", 10)
            old_target_t = getattr(game, "target_time", 60.0)
            
            game = GameState()
            # 状態をリセットした直後に後半のワイプ（スライドアウト）を開始
            game.start_wipe(None) # バーのデータ生成用
            game.wipe_timer = 0.7
            
            if mode == "GAMEOVER_RETRY_ANIM":
                game.mode = old_mode_attr
                game.target_floor = old_target_f
                game.target_time = old_target_t
                game.enter_lobby(play_music=False)
                game.start_countdown(with_wipe=False)
            else:
                # ロビーへ戻る
                game.enter_lobby()
            
            # 初期化（GameState生成）にかかった時間を吸収し、次フレームのdtが跳ね上がるのを防ぐ
            clock.tick()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.KEYDOWN:
                # 階層移動アニメーション中やボス演出中は入力を受け付けない
                if game.transition_direction != 0 or game.state == "BOSS_INTRO":
                    continue

                if game.state == "TITLE":
                    if event.key in (pygame.K_z, pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT):
                        if game.se_start: game.se_start.play()
                        game.enter_lobby()
                elif game.state == "LOBBY":
                    # 言語切り替えマスでの操作
                    if event.key == pygame.K_z:
                        if (game.player_x, game.player_y) == game.lang_tile_pos:
                            game.lang = "EN" if game.lang == "JP" else "JP"
                            game.save_data["lang"] = game.lang
                            SaveManager.save(game.save_data)
                            if game.se_puff: game.se_puff.play()

                    if event.key == pygame.K_UP: game.process_turn(0, -1)
                    elif event.key == pygame.K_DOWN: game.process_turn(0, 1)
                    elif event.key == pygame.K_LEFT: game.process_turn(-1, 0)
                    elif event.key == pygame.K_RIGHT: game.process_turn(1, 0)
                elif game.state in ("PLAYING", "BOSS"):
                    # BOSS_INTRO 中や、変身演出中、重撃演出中などは入力を受け付けない
                    if getattr(game, "boss_intro_state", None) or game.boss_transform_timer > 0 or game.heavy_atk_timer > 0:
                        continue
                    
                    keys = pygame.key.get_pressed()
                    
                    if event.key == pygame.K_z:
                        if animation_timer - last_z_press_time <= DOUBLE_TAP_THRESH:
                            game.wait_anim_timer = 0.15
                            game.end_player_turn()
                            last_z_press_time = -1.0
                        else:
                            last_z_press_time = animation_timer
                    elif keys[pygame.K_z]:
                        if event.key == pygame.K_UP: game.use_skill("UP")
                        elif event.key == pygame.K_DOWN: game.use_skill("DOWN")
                        elif event.key == pygame.K_LEFT: game.use_skill("LEFT")
                        elif event.key == pygame.K_RIGHT: game.use_skill("RIGHT")
                    else:
                        if event.key == pygame.K_UP: game.process_turn(0, -1)
                        elif event.key == pygame.K_DOWN: game.process_turn(0, 1)
                        elif event.key == pygame.K_LEFT: game.process_turn(-1, 0)
                        elif event.key == pygame.K_RIGHT: game.process_turn(1, 0)
                elif game.state == "SHOP":
                    keys = pygame.key.get_pressed()
                    
                    if event.key == pygame.K_z:
                        if animation_timer - last_z_press_time <= DOUBLE_TAP_THRESH:
                            game.wait_anim_timer = 0.15
                            # ショップではターンは経過させないが、アニメーションだけ見せる
                            last_z_press_time = -1.0
                        else:
                            last_z_press_time = animation_timer
                            
                    if event.key in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT):
                        if keys[pygame.K_z]:
                            # Zキーと併用でスキルセット/購入
                            direction = ""
                            if event.key == pygame.K_UP: direction = "UP"
                            elif event.key == pygame.K_DOWN: direction = "DOWN"
                            elif event.key == pygame.K_LEFT: direction = "LEFT"
                            elif event.key == pygame.K_RIGHT: direction = "RIGHT"
                            game.purchase_item(direction)
                        else:
                            # 通常移動
                            dx, dy = 0, 0
                            if event.key == pygame.K_UP: dy = -1
                            elif event.key == pygame.K_DOWN: dy = 1
                            elif event.key == pygame.K_LEFT: dx = -1
                            elif event.key == pygame.K_RIGHT: dx = 1
                            
                            # ショップ内移動制限 (0-8)
                            nx, ny = game.player_x + dx, game.player_y + dy
                            if 0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE:
                                if game.move_anim_timer <= 0: # アニメーション中でなければ
                                    game.move_anim_dx = -dx
                                    game.move_anim_dy = -dy
                                    game.move_anim_timer = 0.075
                                    if game.se_move: game.se_move.play()
                                    game.player_x = nx
                                    game.player_y = ny
                                    game.player_facing_dx = dx
                                    game.player_facing_dy = dy
                                    
                                    # 出口判定 (ショップ)
                                    if (nx, ny) == game.shop_exit_pos:
                                        game.exit_shop()
                elif game.state == "GAMEOVER":
                    if event.key == pygame.K_UP:
                        game.gameover_selection = (game.gameover_selection - 1) % 3
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_DOWN:
                        game.gameover_selection = (game.gameover_selection + 1) % 3
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_z:
                        if game.gameover_selection == 0:
                            game.start_wipe(lambda: setattr(game, "needs_reset", "GAMEOVER_RETRY_ANIM"))
                            if game.se_start: game.se_start.play()
                        elif game.gameover_selection == 1:
                            game.start_wipe(lambda: setattr(game, "needs_reset", "GAMEOVER_TITLE_ANIM"))
                            if game.se_move: game.se_move.play()
                        elif game.gameover_selection == 2:
                            # 結果の保存（スクリーンショット）とシェア
                            try:
                                timestamp = pygame.time.get_ticks()
                                filename = f"result_{timestamp}.png"
                                pygame.image.save(screen, filename)
                                copy_image_to_clipboard(filename)
                                
                                # X (Twitter) へ投稿
                                share_text = f"GUMI-TAWAで {game.floor}cm まで登ったよ！ #GumiTawa"
                                share_url = f"https://twitter.com/intent/tweet?text={urllib.parse.quote(share_text)}"
                                webbrowser.open(share_url)
                                
                                if game.se_heal: game.se_heal.play()
                            except Exception as e:
                                print("Sharing failed:", e)
                                if game.se_error: game.se_error.play()
                elif game.state == "GAMECLEAR":
                    if event.key == pygame.K_UP:
                        game.gameclear_selection = (game.gameclear_selection - 1) % 3
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_DOWN:
                        game.gameclear_selection = (game.gameclear_selection + 1) % 3
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_z:
                        if game.gameclear_selection == 0:
                            # もういちど（現在のモードでリセット）
                            game.start_wipe(lambda: setattr(game, "needs_reset", "GAMEOVER_RETRY_ANIM"))
                            if game.se_start: game.se_start.play()
                        elif game.gameclear_selection == 1:
                            # ロビーへ戻る
                            game.start_wipe(lambda: setattr(game, "needs_reset", "GAMEOVER_TITLE_ANIM"))
                            if game.se_move: game.se_move.play()
                        elif game.gameclear_selection == 2:
                            # 結果の保存（スクリーンショット）とシェア
                            try:
                                timestamp = pygame.time.get_ticks()
                                filename = f"clear_{timestamp}.png"
                                pygame.image.save(screen, filename)
                                copy_image_to_clipboard(filename)
                                
                                # X (Twitter) へ投稿
                                share_text = f"GUMI-TAWAを制覇！ {game.floor}cm 到達！ #GumiTawa"
                                share_url = f"https://twitter.com/intent/tweet?text={urllib.parse.quote(share_text)}"
                                webbrowser.open(share_url)
                                
                                if game.se_heal: game.se_heal.play()
                            except Exception as e:
                                print("Sharing failed:", e)
                                if game.se_error: game.se_error.play()
                elif game.state == "LOBBY_MENU":
                    if event.key == pygame.K_UP:
                        game.target_floor = min(100, game.target_floor + 5)
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_DOWN:
                        game.target_floor = max(5, game.target_floor - 5)
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_RIGHT:
                        game.state = "LOBBY"
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_z:
                        game.mode = "TIME_ATTACK"
                        game.start_countdown()
                        if game.se_start: game.se_start.play()
                elif game.state == "LOBBY_LIMIT_MENU":
                    if event.key == pygame.K_UP:
                        game.target_time = min(300.0, game.target_time + 30.0)
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_DOWN:
                        game.target_time = max(30.0, game.target_time - 30.0)
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_RIGHT:
                        game.state = "LOBBY"
                        if game.se_move: game.se_move.play()
                    elif event.key == pygame.K_z:
                        game.mode = "TIME_LIMIT"
                        game.time_left = game.target_time
                        game.start_countdown()
                        if game.se_start: game.se_start.play()

        
        # --- 描画処理 ---
        # 共通のアニメーション計算
        jiggle_y = int(abs(math.sin(animation_timer * 5.0)) * 5)
        p_wave = math.sin(animation_timer * 15.0 + game.player_x * 1.5 + game.player_y * 2.5)
        p_puyo_x = int(p_wave * 2)
        p_puyo_y = int(-p_wave * 2)

        # 階層移動オフセット
        grid_y_offset = 0
        if game.transition_direction == 1:
            grid_y_offset = 0 # 前のフロアはそのまま残る
        elif game.transition_direction == -1:
            grid_y_offset = -game.transition_timer * HEIGHT

        # --- 全画面: ダイナミック宇宙背景 ---
        game.draw_sky_gradient(screen, (0, 0, WIDTH, HEIGHT))
        
        # UI用カラーの決定 (背景の明るさに合わせる or 5cm以上)
        sky_color = game.get_sky_color()
        brightness = sum(sky_color) / 3
        is_dark = brightness < 200 or game.floor > 5
        ui_color = (200, 230, 255) if is_dark else (40, 60, 120)
        star_alpha_base = max(0, min(255, (game.floor - 0) * 8))
        if star_alpha_base > 0:
            stars_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            for s in game.stars:
                twinkle = (math.sin(animation_timer * s["speed"] + s["phase"]) + 1) / 2
                alpha = int(star_alpha_base * twinkle)
                if alpha > 0:
                    pygame.draw.circle(stars_surf, (255, 255, 255, alpha), (int(s["x"]), int(s["y"])), int(s["size"]))
            screen.blit(stars_surf, (0, 0))
        
        # 着地時のバウンド演出
        land_y = 0
        if game.landing_jiggle_timer > 0:
            lp = game.landing_jiggle_timer / 0.3
            land_y = int(math.sin(lp * 25) * 8 * lp)
        z_base = - (grid_y_offset + land_y)

        if game.state == "TITLE":
            def _(key): return TRANSLATIONS[game.lang][key]
            draw_gummy_text(screen, "GUMI", 258, 60, 15, PLAYER_COLOR, animation_timer)
            draw_gummy_text(screen, "TAWA", 258, 160, 15, EXIT_COLOR, animation_timer)
            alpha = int(abs(math.sin(animation_timer * 3)) * 255)
            temp_surface = font.render(_("msg_press_z"), True, BLACK)
            temp_surface.set_alpha(alpha)
            screen.blit(temp_surface, (280, 310))
        else:
            def _(key): return TRANSLATIONS[game.lang][key]
            # 統一レンダリングタスクの収集
            render_tasks = []
            
            # 描画レイヤーの収集 (下から順に)
            floors_to_draw = []
            scroll_prog = game.scroll_timer / 0.4
            scroll_offset = scroll_prog * 30
            
            if game.transition_timer > 0 and hasattr(game, "old_floor_data"):
                # 1. 落下中: 前の階(z=0) + 新しい階(降下中)
                floors_to_draw.append({"data": game.old_floor_data, "z": land_y, "current": False, "simple": False})
                # 降ってくるフロア (最上段なのでシンプル化しない。落下の高さは内部で計算)
                floors_to_draw.append({"data": None, "z": land_y, "current": True, "simple": False})
            elif game.scroll_timer > 0 and hasattr(game, "old_floor_data"):
                # 2. 着地後スクロール中: 
                # 前の階は今の階の「土台（foundation）」によって完全に隠れるため、描画をスキップして軽量化（中抜き）
                # 今の階 (最上段) のみを描画
                floors_to_draw.append({"data": None, "z": land_y + scroll_offset, "current": True, "simple": False})
            else:
                # 3. 通常時: 今の階のみ
                floors_to_draw.append({"data": None, "z": land_y, "current": True, "simple": False})

            for f_layer in floors_to_draw:
                collect_floor_tasks(screen, game, f_layer["data"], f_layer["z"], animation_timer, render_tasks, 
                                     is_current=f_layer["current"], is_simple=f_layer.get("simple", False),
                                     only_floor=f_layer.get("only_floor", False))

            # 6. 回復エフェクト (パーティクルとテキスト。最前面なので最後に独立して追加)
            z_base_top = land_y # 最上段の基準
            for hp in game.heal_particles:
                def draw_heal_p(screen, x_px, y_px, life, size, zb):
                    gx, gy = x_px / CELL_SIZE, y_px / CELL_SIZE
                    # life は 1.2 から 0 へ減少
                    h_prog = (1.2 - life)
                    px, py = to_iso(gx, gy, zb + 35 + h_prog * 80)
                    alpha = int(max(0, min(255, (life/1.2) * 255)))
                    s = pygame.Surface((size, size), pygame.SRCALPHA)
                    # 「＋」を描画
                    c = (200, 255, 200, alpha)
                    thickness = max(1, size // 4)
                    pygame.draw.line(s, c, (size//2, 0), (size//2, size), thickness)
                    pygame.draw.line(s, c, (0, size//2), (size, size//2), thickness)
                    screen.blit(s, (px - size//2, py - size//2))
                render_tasks.append({
                    "depth": (hp["x"]/CELL_SIZE) * 12 + (hp["y"]/CELL_SIZE) * 30 + 1000,
                    "func": draw_heal_p,
                    "args": (screen, hp["x"], hp["y"], hp["life"], hp["size"], z_base_top)
                })

            for ht in game.heal_texts:
                def draw_heal_t(screen, x_px, y_px, life, text, zb):
                    gx, gy = x_px / CELL_SIZE, y_px / CELL_SIZE
                    # life は 1.5 から 0 へ減少
                    h_prog = (1.5 - life)
                    px, py = to_iso(gx, gy, zb + 50 + h_prog * 40)
                    alpha = int(max(0, min(255, (life/1.5) * 255)))
                    t_surf = title_font.render(text, True, (50, 255, 50))
                    t_surf.set_alpha(alpha)
                    screen.blit(t_surf, (px - t_surf.get_width()//2, py - t_surf.get_height()//2))
                render_tasks.append({
                    "depth": (ht["x"]/CELL_SIZE) * 12 + (ht["y"]/CELL_SIZE) * 30 + 1010,
                    "func": draw_heal_t,
                    "args": (screen, ht["x"], ht["y"], ht["life"], ht["text"], z_base_top)
                })

            # 7. 吹き飛んでいる実体
            for f in game.flying_enemies:
                def draw_flying(screen, fx, fy, ftype, life, max_life, zb):
                    gx, gy = fx / CELL_SIZE, fy / CELL_SIZE
                    prog = 1.0 - (life / max_life)
                    fz = zb + math.sin(prog * math.pi) * 200
                    if ftype == "WALL": draw_tile(screen, gx, gy, fz, None, animation_timer, {})
                    elif ftype.startswith("ITEM_"):
                        itype = ftype.split("_")[1]; px, py = to_iso(gx+0.5, gy+0.5, fz)
                        draw_item_icon(screen, int(px-10), int(py-10), 20, itype)
                    else:
                        c = ENEMY_COLORS.get(ftype, ENEMY_COLORS["E1"])
                        draw_gummy_char(screen, gx, gy, fz, c, 0.8, ftype, 1, 0, animation_timer, is_damaged=True)
                render_tasks.append({
                    "depth": (f["x"]/CELL_SIZE) * 12 + (f["y"]/CELL_SIZE) * 30 + 1100,
                    "func": draw_flying,
                    "args": (screen, f["x"], f["y"], f["type"], f["timer"], f.get("max_timer", 0.5), z_base_top)
                })

            # ソートして実行
            render_tasks.sort(key=lambda t: t["depth"])
            for task in render_tasks:
                task["func"](*task["args"])

            # ボスのHPバー
            if game.boss_active:
                hp_x, hp_y = 400 - 150, 50
                # ボス名
                draw_text(screen, _("ui_boss_name"), hp_x, hp_y - 30, ui_color, font_obj=font)
                # バー本体
                pygame.draw.rect(screen, (50, 0, 50), (hp_x-2, hp_y-2, 304, 14), border_radius=5)
                pygame.draw.rect(screen, (255, 50, 100), (hp_x, hp_y, int(300 * (game.boss_hp/game.boss_max_hp)), 10), border_radius=3)

            # ロビーのテキスト（ソート対象外でOK）

            if game.state in ("LOBBY", "LOBBY_MENU", "LOBBY_LIMIT_MENU"):
                def _(key): return TRANSLATIONS[game.lang][key]
                tx, ty = to_iso(4.5, 3.5, z_base)
                draw_text(screen, _("title_endless"), tx-30, ty, BLACK, small_font)
                ttx, tty = to_iso(7.5, 3.5, z_base)
                draw_text(screen, _("title_time_attack"), ttx-40, tty, BLACK, small_font)
                tlt_x, tlt_y = to_iso(1.5, 3.5, z_base)
                draw_text(screen, _("title_time_limit"), tlt_x-40, tlt_y, BLACK, small_font)
                
                # 言語切替ラベル
                lx, ly = to_iso(4.5, 0.5, z_base)
                draw_text(screen, _("label_lang"), lx-40, ly, BLACK, small_font)
                
                # 遊びかたマスのラベル
                hx, hy = to_iso(3.5, 6.5, z_base)
                draw_text(screen, _("label_how_to"), hx-25, hy, BLACK, small_font)
                
                # スキル解説マスのラベル
                sx, sy = to_iso(5.5, 6.5, z_base)
                draw_text(screen, _("label_skills"), sx-35, sy, BLACK, small_font)

                # キャラクター一覧マスのラベル
                cx, cy = to_iso(7.5, 6.5, z_base)
                draw_text(screen, _("label_chars"), cx-35, cy, BLACK, small_font)

                # ストーリーマスのラベル
                stx, sty = to_iso(1.5, 6.5, z_base)
                draw_text(screen, _("label_story"), stx-25, sty, BLACK, small_font)


        # 演出用パーティクル
        for p in game.particles:
            pygame.draw.circle(screen, p.get("color", WHITE), (int(p["x"]), int(p["y"] + grid_y_offset)), int(p["size"]//2))

        # 左パネルUI
        # ピンチ時の警告色
        time_color = (255, 100, 100) if game.time_left < 5 else ui_color
        hp_color = (255, 100, 100) if game.hp <= 3 else ui_color
        
        j_color = (255, 180, 255) if is_dark else (180, 50, 180)
        g_color = (255, 255, 150) if is_dark else (150, 140, 0)

        def _(key): return TRANSLATIONS[game.lang][key]
        draw_gummy_text(screen, "GUMI", 15, 10, 3, PLAYER_COLOR, animation_timer)
        draw_gummy_text(screen, "TAWA", 15, 38, 3, EXIT_COLOR, animation_timer)
        
        # 指定された順番に配置 (たかさ -> 残りターン -> 残り時間 -> 経過時間 -> HP)
        draw_text(screen, f"{_('ui_floor')}: {game.floor}cm", 18, 70, color=ui_color, font_obj=title_font)
        turn_val = '∞' if game.state == 'BOSS' else game.turns_left
        draw_text(screen, f"{_('ui_turns')} {turn_val}{_('ui_turns_unit')}", 18, 105, color=ui_color)
        time_label = _("ui_time_left") if game.mode != "TIME_LIMIT" else _("ui_time_limit")
        draw_text(screen, f"{time_label} {max(0, game.time_left):.1f}s", 18, 135, color=time_color)
        draw_text(screen, f"{_('ui_elapsed')}: {game.total_time:.1f}s", 18, 165, color=ui_color)
        draw_text(screen, f"{_('ui_hp')}: {game.hp}/10", 18, 195, color=hp_color)
        
        draw_item_icon(screen, 15, 230, 24, "J"); draw_text(screen, f": {game.j}", 42, 230, j_color)
        draw_item_icon(screen, 105, 230, 24, "G"); draw_text(screen, f": {game.g}", 132, 230, g_color)

        # --- 爆発フラッシュ演出 ---
        if game.bomb_flash_timer > 0:
            alpha = 0
            if game.bomb_flash_timer > 1.0: # 最初の1秒で白くなっていく
                alpha = int(min(255, (2.0 - game.bomb_flash_timer) * 510))
            else: # 次の1秒で消えていく
                alpha = int(max(0, game.bomb_flash_timer * 255))
            
            s = pygame.Surface((WIDTH, HEIGHT))
            s.set_alpha(alpha)
            s.fill(WHITE)
            screen.blit(s, (0,0))


        # スキルスロット
        s_layout = [("UP", 75, 310), ("LEFT", 10, 375), ("RIGHT", 140, 375), ("DOWN", 75, 440)]
        skill_panel_color = (40, 60, 120) # 階層にかかわらず紺色を維持
        for key_dir, sx, sy in s_layout:
            draw_skill_icon(screen, sx, sy, 36, game.skills[key_dir], color=skill_panel_color)
            # スキルの必要数テキストも紺色に固定
            draw_text(screen, f"J{ALL_SKILLS.get(game.skills[key_dir],{'j':0})['j']} G{ALL_SKILLS.get(game.skills[key_dir],{'g':0})['g']}", sx, sy+55, color=skill_panel_color, font_obj=small_font)

        # --- 地表ワイプ (PiP) ---
        wipe_x, wipe_y = 585, 385
        wipe_w, wipe_h = 200, 200
        # 枠線と影
        pygame.draw.rect(screen, (50, 50, 80), (wipe_x+4, wipe_y+4, wipe_w, wipe_h), border_radius=15) # 影
        pygame.draw.rect(screen, WHITE, (wipe_x, wipe_y, wipe_w, wipe_h), border_radius=15) # 外枠
        
        # 中身 (クリッピング用のサブサーフェスっぽく描画)
        inner_margin = 4
        ix, iy, iw, ih = wipe_x+inner_margin, wipe_y+inner_margin, wipe_w-inner_margin*2, wipe_h-inner_margin*2
        pygame.draw.rect(screen, (135, 206, 235), (ix, iy, iw, ih), border_radius=12) # 空
        pygame.draw.rect(screen, (101, 67, 33), (ix, iy+ih-30, iw, 30), border_bottom_left_radius=12, border_bottom_right_radius=12) # 地面
        pygame.draw.rect(screen, (34, 139, 34), (ix, iy+ih-30, iw, 6)) # 芝生
        
        draw_text(screen, f"{_('ui_surface')} ({game.dropped_enemies}/{game.DROPPED_TO_BOSS})", ix+10, iy+10, (50, 70, 150), small_font)
        
        # ショップUI (タイマーと商品説明)
        if game.state == "SHOP":
            on_item = None
            for i, pos in enumerate(game.shop_item_pos):
                if i < len(game.shop_offers) and game.player_x == pos[0] and game.player_y == pos[1]:
                    on_item = game.shop_offers[i]
                    break
            
            if on_item:
                panel_rect = (GRID_OFFSET_X + 20, 480, 320, 100)
                pygame.draw.rect(screen, WHITE, panel_rect, border_radius=12)
                pygame.draw.rect(screen, BLACK, panel_rect, width=2, border_radius=12)
                draw_text(screen, f"【{on_item['name']}】", panel_rect[0]+10, panel_rect[1]+10, font_obj=font)
                draw_text(screen, on_item["desc"], panel_rect[0]+10, panel_rect[1]+40, font_obj=small_font)
                draw_text(screen, "Z + [↑↓←→] 購入", panel_rect[0]+10, panel_rect[1]+70, font_obj=small_font)

            timer_color = (255, 50, 50) if game.shop_timer < 5 else ui_color
            draw_gummy_text(screen, f"{int(game.shop_timer)}", 400, 50, 10, timer_color, animation_timer)
        for pe in game.pool_enemies:
            sq = int(math.sin(pe["phase"]) * 2)
            c = PLAYER_COLOR if pe["type"] == "PLAYER" else ENEMY_COLORS.get(pe["type"], ENEMY_COLORS["E1"])
            # 物理演算のローカル座標 (0-192) をワイプの内部座標 (ix, iy) に加算
            px = pe["x"] + ix
            py = pe["y"] + iy
            if iy - 50 <= py <= iy + ih: # 少し上から描画開始を許可
                # 本体
                r = pe["radius"]
                body_rect = (px-r-sq//2, py-r-sq, r*2+sq, r*2+sq)
                pygame.draw.rect(screen, c, body_rect, border_radius=int(r * 0.9))
                # 目 (個別の状態に基づいたランダムな表情変化)
                eye_size = max(1, int(r // 4))
                eye_y = py - r // 4 - sq
                eye_type = pe.get("eye_type", "NORMAL")
                
                if eye_type == "NORMAL":
                    pygame.draw.circle(screen, (0, 0, 0), (int(px - r // 2), int(eye_y)), eye_size)
                    pygame.draw.circle(screen, (0, 0, 0), (int(px + r // 2), int(eye_y)), eye_size)
                elif eye_type == "FLAT":
                    pygame.draw.line(screen, (0, 0, 0), (int(px - r // 2 - eye_size), int(eye_y)), (int(px - r // 2 + eye_size), int(eye_y)), 1)
                    pygame.draw.line(screen, (0, 0, 0), (int(px + r // 2 - eye_size), int(eye_y)), (int(px + r // 2 + eye_size), int(eye_y)), 1)
                elif eye_type == "SQUEEZE":
                    s = eye_size
                    pygame.draw.line(screen, (0,0,0), (int(px-r//2-s), int(eye_y-s)), (int(px-r//2), int(eye_y)), 1)
                    pygame.draw.line(screen, (0,0,0), (int(px-r//2-s), int(eye_y+s)), (int(px-r//2), int(eye_y)), 1)
                    pygame.draw.line(screen, (0,0,0), (int(px+r//2+s), int(eye_y-s)), (int(px+r//2), int(eye_y)), 1)
                    pygame.draw.line(screen, (0,0,0), (int(px+r//2+s), int(eye_y+s)), (int(px+r//2), int(eye_y)), 1)
                elif eye_type == "SMILE":
                    s = eye_size * 1.2
                    pygame.draw.line(screen, (0,0,0), (int(px-r//2-s), int(eye_y-s)), (int(px-r//2), int(eye_y)), 2)
                    pygame.draw.line(screen, (0,0,0), (int(px-r//2-s), int(eye_y+s)), (int(px-r//2), int(eye_y)), 2)
                    pygame.draw.line(screen, (0,0,0), (int(px+r//2+s), int(eye_y-s)), (int(px+r//2), int(eye_y)), 2)
                    pygame.draw.line(screen, (0,0,0), (int(px+r//2+s), int(eye_y+s)), (int(px+r//2), int(eye_y)), 2)

        if game.state in ("GAMEOVER", "GAMEOVER_RETRY_ANIM", "GAMEOVER_TITLE_ANIM"):
            res_rect = (250, 80, 300, 420)
            # 影
            pygame.draw.rect(screen, (30, 30, 50), (res_rect[0]+5, res_rect[1]+5, res_rect[2], res_rect[3]), border_radius=20)
            # ウィンドウ本体 (透過あり)
            overlay = pygame.Surface((res_rect[2], res_rect[3]), pygame.SRCALPHA)
            pygame.draw.rect(overlay, (255, 235, 245, 220), (0, 0, res_rect[2], res_rect[3]), border_radius=20)
            screen.blit(overlay, (res_rect[0], res_rect[1]))
            pygame.draw.rect(screen, WHITE, res_rect, width=3, border_radius=20)
            
            draw_text(screen, "RESULT", 345, 100, (255, 100, 150), title_font)
            
            h_f = bold_font if game.mode in ("TIME_LIMIT", "ENDLESS") else font
            t_f = bold_font if game.mode in ("TIME_LIMIT", "TIME_ATTACK") else font
            
            draw_text(screen, f"{_('ui_floor')}: {game.floor}cm", 300, 180, font_obj=h_f)
            draw_text(screen, f"{_('ui_elapsed')}: {game.total_time:.1f}s", 300, 220, font_obj=t_f)
            for idx, txt in enumerate([_("msg_retry"), _("msg_back_lobby"), _("msg_save")]):
                c = (255, 150, 50) if game.gameover_selection == idx else BLACK
                draw_text(screen, ("> " if game.gameover_selection == idx else "  ") + txt, 340, 320 + idx*40, c)
            
            mode_map = {"ENDLESS": _("title_endless"), "TIME_ATTACK": _("title_time_attack"), "TIME_LIMIT": _("title_time_limit")}
            m_txt = mode_map.get(game.mode, "???") + (" Mode" if game.lang == "EN" else "モード")
            if game.mode == "TIME_ATTACK": m_txt += f" [{int(game.target_floor)}cm]"
            elif game.mode == "TIME_LIMIT": m_txt += f" [{int(game.target_time)}s]"
            draw_text(screen, m_txt, 320, 465, (120, 100, 150), small_font)
        elif game.state == "COUNTDOWN":
            num = int(math.ceil(game.countdown_timer))
            txt = "START!" if num == 0 else str(num)
            txt_surf = huge_font.render(txt, True, (255, 150, 50) if num == 0 else BLACK)
            screen.blit(txt_surf, (400 - txt_surf.get_width()//2, 300 - txt_surf.get_height()//2))
        elif game.state == "LOBBY_MENU":
            def _(key): return TRANSLATIONS[game.lang][key]
            pygame.draw.rect(screen, (250, 240, 250), (250, 200, 300, 160), border_radius=12)
            draw_text(screen, _("menu_ta_target"), 280, 220, BLACK, font)
            draw_text(screen, f"↑ {game.target_floor}cm ↓", 340, 260, (255, 50, 50), title_font)
            draw_text(screen, _("menu_controls"), 280, 315, (100, 100, 150), small_font)
        elif game.state == "LOBBY_LIMIT_MENU":
            def _(key): return TRANSLATIONS[game.lang][key]
            pygame.draw.rect(screen, (240, 250, 255), (250, 200, 300, 160), border_radius=12)
            draw_text(screen, _("menu_tl_limit"), 280, 220, BLACK, font)
            draw_text(screen, f"↑ {int(game.target_time)} " + ("sec" if game.lang == "EN" else "秒") + " ↓", 340, 260, (50, 50, 255), title_font)
            draw_text(screen, _("menu_controls"), 280, 315, (100, 100, 150), small_font)
        elif game.state == "GAMECLEAR":
            res_rect = (250, 80, 300, 420)
            # 影
            pygame.draw.rect(screen, (30, 30, 50), (res_rect[0]+5, res_rect[1]+5, res_rect[2], res_rect[3]), border_radius=20)
            # ウィンドウ本体 (透過あり - クリア時は少し黄色み)
            overlay = pygame.Surface((res_rect[2], res_rect[3]), pygame.SRCALPHA)
            pygame.draw.rect(overlay, (255, 250, 220, 230), (0, 0, res_rect[2], res_rect[3]), border_radius=20)
            screen.blit(overlay, (res_rect[0], res_rect[1]))
            pygame.draw.rect(screen, (255, 200, 50), res_rect, width=3, border_radius=20)
            
            if game.mode == "TIME_LIMIT": draw_text(screen, _("res_time_up"), 330, 100, (50, 100, 255), title_font)
            else: draw_text(screen, _("res_clear"), 310, 100, (255, 180, 50), title_font)
            
            h_f = bold_font if game.mode in ("TIME_LIMIT", "ENDLESS") else font
            t_f = bold_font if game.mode in ("TIME_LIMIT", "TIME_ATTACK") else font
            
            draw_text(screen, f"{_('ui_floor')}: {game.floor}cm", 300, 175, font_obj=h_f)
            draw_text(screen, f"{_('res_total_turns')}: {game.total_turns_taken} {_('ui_turns_unit')}", 300, 210)
            label = _("ui_time_limit") if game.mode == "TIME_LIMIT" else _("res_clear_time")
            draw_text(screen, f"{label}: {game.total_time:.1f}s", 300, 245, font_obj=t_f)
            for idx, txt in enumerate([_("res_retry"), _("msg_back_lobby"), _("res_share")]):
                c = (255, 150, 50) if game.gameclear_selection == idx else BLACK
                draw_text(screen, ("> " if game.gameclear_selection == idx else "  ") + txt, 340, 320 + idx*40, c)

            mode_map = {"ENDLESS": _("title_endless"), "TIME_ATTACK": _("title_time_attack"), "TIME_LIMIT": _("title_time_limit")}
            m_txt = mode_map.get(game.mode, "???") + (" Mode" if game.lang == "EN" else "モード")
            if game.mode == "TIME_ATTACK": m_txt += f" [{int(game.target_floor)}cm]"
            elif game.mode == "TIME_LIMIT": m_txt += f" [{int(game.target_time)}s]"
            draw_text(screen, m_txt, 320, 465, (120, 100, 150), small_font)

        # --- 最前面のポップアップ演出 (ロビーのヘルプ等) ---
        if game.state == "LOBBY":
            def _(key): return TRANSLATIONS[game.lang][key]
            # ヘルプポップアップ
            if game.player_x == 3 and game.player_y == 7:
                h_rect = (200, 120, 400, 300)
                # 半透明背景
                h_surf = pygame.Surface((h_rect[2], h_rect[3]), pygame.SRCALPHA)
                pygame.draw.rect(h_surf, (255, 255, 240, 220), (0, 0, h_rect[2], h_rect[3]), border_radius=15)
                screen.blit(h_surf, (h_rect[0], h_rect[1]))
                # 枠線
                pygame.draw.rect(screen, (100, 80, 50), h_rect, width=2, border_radius=15)
                draw_text(screen, _("how_to_title"), h_rect[0]+130, h_rect[1]+20, (80, 50, 20), font)
                guide = [
                    _("how_to_1"),
                    _("how_to_2"),
                    _("how_to_3"),
                ]
                for i, line in enumerate(guide):
                    draw_text(screen, line, h_rect[0]+30, h_rect[1]+70 + i*40, BLACK, small_font)
            
            # スキル解説ポップアップ
            if game.player_x == 5 and game.player_y == 7:
                s_rect = (150, 70, 500, 460)
                # 半透明背景
                s_surf = pygame.Surface((s_rect[2], s_rect[3]), pygame.SRCALPHA)
                pygame.draw.rect(s_surf, (240, 240, 255, 220), (0, 0, s_rect[2], s_rect[3]), border_radius=15)
                screen.blit(s_surf, (s_rect[0], s_rect[1]))
                # 枠線
                pygame.draw.rect(screen, (50, 50, 150), s_rect, width=2, border_radius=15)
                draw_text(screen, _("skill_title"), s_rect[0]+180, s_rect[1]+15, (20, 20, 100), font)
                
                skill_list = list(ALL_SKILLS.keys())
                skill_trans_keys = {
                    "回復": "skill_heal", "貫通": "skill_pierce", "回転": "skill_spin", "投擲": "skill_throw",
                    "停止": "skill_stop", "跳躍": "skill_jump", "重撃": "skill_heavy", "自爆": "skill_bomb"
                }
                for i, name in enumerate(skill_list):
                    data = ALL_SKILLS[name]
                    iy = s_rect[1] + 55 + i * 48
                    draw_skill_icon(screen, s_rect[0] + 30, iy, 36, name, color=(40, 60, 120))
                    cost_text = f"J:{data['j']} G:{data['g']}"
                    if data['j'] < 0: cost_text = "J:ALL G:ALL"
                    draw_text(screen, cost_text, s_rect[0] + 80, iy + 8, (100, 50, 150), small_font)
                    desc = _(skill_trans_keys[name])
                    draw_text(screen, f": {desc}", s_rect[0] + 180, iy + 8, BLACK, small_font)

            # キャラクター一覧ポップアップ
            if game.player_x == 7 and game.player_y == 7:
                c_rect = (60, 40, 680, 520)
                # 半透明背景
                c_surf = pygame.Surface((c_rect[2], c_rect[3]), pygame.SRCALPHA)
                pygame.draw.rect(c_surf, (250, 245, 255, 230), (0, 0, c_rect[2], c_rect[3]), border_radius=15)
                screen.blit(c_surf, (c_rect[0], c_rect[1]))
                # 枠線
                pygame.draw.rect(screen, (80, 60, 120), c_rect, width=2, border_radius=15)
                draw_text(screen, _("char_title"), c_rect[0]+260, c_rect[1]+15, (60, 40, 100), font)
                
                # 1. 自機
                draw_gummy_char_ui(screen, c_rect[0] + 50, c_rect[1] + 80, PLAYER_COLOR, 0.8, "PLAYER", animation_timer)
                draw_text(screen, _("char_me"), c_rect[0] + 100, c_rect[1] + 75, BLACK, small_font)
                
                # 2. 敵キャラ
                y_off = c_rect[1] + 135
                enemies_data = [
                    ("E1", _("char_e1")),
                    ("E2", _("char_e2")),
                    ("E3", _("char_e3")),
                    ("E4", _("char_e4"))
                ]
                for etype, desc in enemies_data:
                    draw_gummy_char_ui(screen, c_rect[0] + 50, y_off + 20, ENEMY_COLORS[etype], 0.7, etype, animation_timer)
                    draw_text(screen, desc, c_rect[0] + 100, y_off + 12, BLACK, small_font)
                    y_off += 55
                
                # 3. ボス
                draw_gummy_char_ui(screen, c_rect[0] + 50, y_off + 25, ENEMY_COLORS["BOSS"], 1.1, "BOSS", animation_timer)
                draw_text(screen, _("char_boss"), c_rect[0] + 100, y_off + 15, BLACK, small_font)
                
                # 4. リソース
                y_off += 75
                draw_item_icon(screen, c_rect[0] + 35, y_off, 32, "J")
                draw_text(screen, _("ui_item_j") + ": " + ("Gummy material. Source of flavor." if game.lang == "EN" else "グミの原料。味や香りの元。"), c_rect[0] + 100, y_off + 5, BLACK, small_font)
                y_off += 50
                draw_item_icon(screen, c_rect[0] + 35, y_off, 32, "G")
                draw_text(screen, _("ui_item_g") + ": " + ("Gummy material. Controls texture." if game.lang == "EN" else "グミの原料。この量で食感をコントロール。"), c_rect[0] + 100, y_off + 5, BLACK, small_font)

            # ストーリーポップアップ
            if game.player_x == 1 and game.player_y == 7:
                st_rect = (180, 80, 440, 460)
                # 半透明背景
                st_surf = pygame.Surface((st_rect[2], st_rect[3]), pygame.SRCALPHA)
                pygame.draw.rect(st_surf, (245, 255, 245, 230), (0, 0, st_rect[2], st_rect[3]), border_radius=15)
                screen.blit(st_surf, (st_rect[0], st_rect[1]))
                # 枠線
                pygame.draw.rect(screen, (50, 100, 50), st_rect, width=2, border_radius=15)
                draw_text(screen, _("story_title"), st_rect[0]+150, st_rect[1]+15, (20, 60, 20), font)
                
                # 画像の表示（未ロードなら試行）
                if game.story_image is None:
                    game.load_story_image()

                if game.story_image:
                    img_x = st_rect[0] + (st_rect[2] - game.story_image.get_width()) // 2
                    img_y = st_rect[1] + 50
                    # 画像の枠
                    pygame.draw.rect(screen, WHITE, (img_x-2, img_y-2, game.story_image.get_width()+4, game.story_image.get_height()+4), border_radius=3)
                    screen.blit(game.story_image, (img_x, img_y))
                    text_y = img_y + game.story_image.get_height() + 25
                else:
                    # 画像がない場合のプレースホルダ
                    pygame.draw.rect(screen, (200, 220, 200), (st_rect[0]+20, st_rect[1]+50, st_rect[2]-40, 180), border_radius=10)
                    draw_text(screen, "(Image Loading...)", st_rect[0]+130, st_rect[1]+130, (80, 120, 80), font)
                    text_y = st_rect[1] + 250
                
                # ストーリー文章
                story_lines = [
                    _("story_1"),
                    _("story_2"),
                    _("story_3"),
                    ""
                ]
                for i, line in enumerate(story_lines):
                    draw_text(screen, line, st_rect[0]+35, text_y + i*28, BLACK, small_font)

        if game.wipe_active:
            for bar in game.wipe_bars:
                # バー個別のプログレス（1.2秒かけて通過）
                bar_dur = 1.2
                prog = max(0, min(1.0, (game.wipe_timer - bar["delay"]) / bar_dur))
                if prog <= 0: continue
                
                r = bar["h"] // 2
                bar_len = WIDTH * 1.6 # さらに短く
                total_dist = WIDTH + bar_len
                x = -bar_len + prog * total_dist
                pygame.draw.rect(screen, bar["color"], (x, bar["y"], bar_len, bar["h"]), border_radius=r)

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
